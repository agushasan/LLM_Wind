# Architecture notes

Extended discussion of Figure 1 in the paper. This document explains *why* the architecture is shaped the way it is, in language that complements the formal account in §3 of the paper.

## The five-layer view

```
   ┌─────────────────────────────────────────────────────────────┐
   │  Data & Knowledge Sources  →  Ξ_k = (𝒴_k, s_k, 𝓗_k)          │
   │     SCADA · maintenance logs · manuals · weather · history  │
   ├─────────────────────────────────────────────────────────────┤
   │  Tool Library  𝒯 = {T1, T2, T3, T4, T5}, T_i: 𝒜_i → 𝒱_i     │
   ├─────────────────────────────────────────────────────────────┤
   │  LLM Agent Core  π_LLM : (q_k, 𝓒_t) → calls or r_k          │
   │     turn budget J_max = 8,  failure token ⊥                 │
   ├─────────────────────────────────────────────────────────────┤
   │  Operator (Human-in-the-Loop)                               │
   │     forward: q_k        reverse: feedback / override        │
   ├─────────────────────────────────────────────────────────────┤
   │  Decision Support Outputs  =  structured projection of r_k   │
   │     diagnosis · explanation · recommendation · alert · WO   │
   └─────────────────────────────────────────────────────────────┘
```

## Why tool calling rather than fine-tuning

Three properties of wind O\&M motivate the tool-calling design over the alternatives discussed in the paper:

1. **The data is large and structured.** A single 30-day SCADA window for one turbine contains 4 320 samples across 12 channels. It is neither token-efficient nor robust to load this into the LLM's context window. T1 returns *summary statistics* computed by deterministic, peer-reviewed code, and the LLM never has to do arithmetic on long numerical sequences.

2. **Every operational claim must be auditable.** When the operator asks "why did you recommend dispatching a vessel?", the answer "because T2 returned an anomaly score of 0.91 at Nov 7 14:00 and T4 retrieved Manual §4.3 which states that score > 0.85 indicates a developing bearing fault" is verifiable. "Because the LLM said so" is not. The tool-call trace in `AgentResult.trace` is exactly that audit object.

3. **The safe envelope of the system must be controllable.** Restricting the LLM to a fixed library of five tools enumerates exactly what the LLM is authorised to do. Adding a new capability is a deliberate engineering decision (new tool implementation, new schema, new unit tests), not an emergent property of model weights.

## What guarantees grounding?

The grounding property (Proposition 1 in the paper) is recovered automatically by the construction, provided the system prompt enforces one invariant:

> The LLM may not emit any digit that does not already appear among the tool return values on the conversation.

The default system prompt (`prompts/system_prompt.txt`) states this explicitly under rule 1. Together with the tool-call loop (`agent/runtime.py`) and the deterministic implementations of T1–T5, this gives every numerical token in `r_k` a deterministic procedure `T` and an argument `α` such that `ν = T(α; Ξ_k)`.

In practice we have observed Qwen3-14B violating this invariant when the system prompt is shortened or when the few-shot example is removed. Keep them.

## What guarantees consistency?

Consistency (Proposition 2) follows from determinism of the tools. The LLM's sampling is stochastic, but the values it can refer to are not. Two runs on the same `(Ξ_k, q_k)` may call tools in a different order, may surface different prose, but the multiset of *numbers* in the final answer will be a sub-multiset of the same finite set `⋃_α { T_i(α; Ξ_k) }`. Floating-point round-off is the only source of true variability, which is below operator-relevant resolution.

## When the agent should abstain

The runtime returns the failure token `⊥` (defined as `BOTTOM` in `agent/runtime.py`) in exactly one case: the turn budget `J_max = 8` is exhausted before the LLM emits a final answer. The intuition is that any operator query that genuinely needs more than eight tool calls is one that should be escalated to a human analyst, not answered automatically.

The system prompt also instructs the model to abstain when:

* tools disagree (e.g. T2 fires but T3 finds no rule violation);
* a tool returns `"insufficient_data"`, `"unknown_channel"`, or `"tool_unavailable"`;
* the operator's query falls outside the action space (no tool can answer it).

These abstentions are *not* `⊥`. They are a normal final response whose content explicitly states the uncertainty and recommends escalation. This is the right behaviour: silent failure would be worse than an explicit "I don't know".

## Per-turn dynamics

The runtime implements equations (7)–(9) directly:

```python
for step in range(1, max_steps + 1):
    msg = client.chat(model, messages, tools=schemas)        # π_LLM(𝓒_t)
    if msg["tool_calls"] is None:
        return AgentResult(answer=msg["content"], ...)        # terminate → r_k
    for c in msg["tool_calls"]:
        result = registry.dispatch(c["name"], c["arguments"]) # v_j = T_{i_j}(α_j; Ξ_k)
        messages.append({"role": "tool", "content": json.dumps(result)})  # 𝓒_{t+1}
return AgentResult(answer=BOTTOM, terminated_normally=False)  # ⊥
```

The structure is shallow on purpose: the only state on the runtime side is `messages`, the conversation `𝓒_t`. Everything else lives in the tools or the registry, where it can be unit-tested in isolation.

## Where the safety guarantees actually break

The grounding and consistency properties are *architectural* guarantees: they hold by construction, provided every individual piece behaves correctly. The failure modes the architecture does **not** rule out are:

* **Bad tool implementations.** If `scada_query` is buggy, the agent is grounded but wrong. Hence the unit tests.
* **Hallucinated planning.** The LLM may call the right tools in the wrong order, or call the wrong tool. The case study suggests this is rare with Qwen3-14B and a well-tuned prompt, but it is not impossible. The operator-override channel is the safety net.
* **Stale data.** If `Ξ_k` lags reality, all guarantees still hold *with respect to `Ξ_k`*. Whether that is good enough is an operational, not architectural, question.

The paper is honest about these. See §6, *Limitations*.
