# Adding a sixth tool

The architecture is deliberately extensible: adding a new capability is a tool-implementation step, not a model-retraining step. This document walks through the four files you touch.

## 1. Implement the tool

Add a new module under `src/wind_llm_agent/tools/`, mirroring the pattern of the existing tools. The function must be a *pure function* of the `SharedState` plus its own arguments, and must return JSON-serialisable values.

```python
# src/wind_llm_agent/tools/vibration_spectrum.py
"""T6 — Vibration-spectrum tool (illustrative)."""

from __future__ import annotations
from typing import Any, Dict
from ..state import SharedState


def vibration_spectrum(
    state: SharedState,
    *,
    start_ts: str,
    end_ts: str,
    band_hz: tuple[float, float] = (50.0, 500.0),
) -> Dict[str, Any]:
    """Return RMS and dominant peak frequency in the requested band."""
    # ... implementation reads from state.scada or an auxiliary
    # high-bandwidth stream attached to the state in __init__.
    return {
        "status": "ok",
        "rms":               42.0,
        "dominant_freq_hz":  120.0,
        "band_hz":           list(band_hz),
        "n_samples":         100_000,
    }
```

Design guidelines:

- **Determinism.** Same arguments + same state → identical output. No clocks, no RNG without a seed, no network calls that depend on time-of-day.
- **No side effects.** Tools can append to `state.event_log` (see `T2` and `T3` for examples), but cannot mutate `state.scada` or write to external systems. Anything that mutates the world goes through a separate explicit channel.
- **Cheap.** Sub-second is the target. Operators routinely chain multiple tool calls; a slow tool blocks the whole loop.
- **Graceful failures.** Return `{"status": "unknown_channel"}` or `{"status": "insufficient_data"}` rather than raising; the agent can reason about these returns, but cannot reason about Python tracebacks.

## 2. Register the schema

Add a JSON-Schema entry to `src/wind_llm_agent/tools/schemas.py`. This is what the LLM actually sees:

```python
{
    "type": "function",
    "function": {
        "name": "vibration_spectrum",
        "description": (
            "Compute RMS and dominant peak frequency of the high-"
            "bandwidth vibration signal over a time window."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "start_ts": {"type": "string"},
                "end_ts":   {"type": "string"},
                "band_hz":  {
                    "type": "array",
                    "items": {"type": "number"},
                    "minItems": 2, "maxItems": 2,
                    "default": [50.0, 500.0],
                },
            },
            "required": ["start_ts", "end_ts"],
        },
    },
}
```

Write the description for the model, not for a human reviewer: be concrete about what the tool returns, what units it uses, and what its limitations are. Vague descriptions produce vague tool calls.

## 3. Wire the registry

In `src/wind_llm_agent/agent/registry.py`, add a branch to `ToolRegistry.dispatch()`:

```python
if name == "vibration_spectrum":
    return vibration_spectrum(self.state, **args)
```

Update `ToolRegistry.names()` to include the new tool. If the tool needs extra backend objects (a vibration-data handle, a calibration table), pass them through the registry constructor and store them as fields, mirroring how `retriever` and `scheduler_ctx` are handled.

## 4. Add unit tests

Add `tests/test_vibration_spectrum.py` with at least: a normal-operation call, an edge-case call (empty window, unknown channel), a determinism check, and one negative test that confirms a bad argument returns a structured error rather than raising. Patterns to copy from the existing test files:

- `tests/test_scada_query.py` — return-value structure tests.
- `tests/test_anomaly_detector.py` — domain-specific detection tests.
- `tests/test_runtime.py` — `_StubClient` pattern for end-to-end tests without a live Ollama.

## 5. Update the system prompt (optional but recommended)

If the new tool changes the agent's recommended workflow, add one or two sentences to `prompts/system_prompt.txt` explaining when to call it. Empirically, Qwen3-14B handles new tools well from schema alone for one-off use, but benefits from prompt guidance when the tool should be chained with existing tools in a specific order.

## Checklist

- [ ] `src/wind_llm_agent/tools/<name>.py` exists and is a pure function.
- [ ] `tools/schemas.py` lists the new schema.
- [ ] `tools/__init__.py` exports the new symbol.
- [ ] `agent/registry.py` dispatches it.
- [ ] `tests/test_<name>.py` covers it.
- [ ] `README.md` table updated.
- [ ] `prompts/system_prompt.txt` mentions it (if the workflow changes).

That's it. No retraining, no fine-tuning, no LLM redeployment.
