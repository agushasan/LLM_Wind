#!/usr/bin/env python
"""Build the FAISS index for the RAG retriever (tool T4).

Inputs a directory of plain-text or markdown documents, chunks them
into ~500-token passages with 50-token overlap, embeds them with a
local sentence-transformer model, and writes the corpus as a JSONL
file ready to be consumed by `RagRetriever.from_jsonl`.

Example
-------
    python scripts/build_rag_index.py \\
        --input data/manuals/ \\
        --output data/corpus.jsonl

The embeddings themselves are computed on-the-fly the first time the
agent runs; this script only produces the chunked corpus file.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Iterable, List

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))


def _chunk(text: str, max_words: int = 500, overlap: int = 50) -> List[str]:
    words = text.split()
    if len(words) <= max_words:
        return [text]
    out: List[str] = []
    i = 0
    while i < len(words):
        out.append(" ".join(words[i:i + max_words]))
        i += max_words - overlap
    return out


def _iter_files(root: Path) -> Iterable[Path]:
    for p in root.rglob("*"):
        if p.suffix.lower() in {".txt", ".md", ".markdown"} and p.is_file():
            yield p


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--input", required=True, help="Directory of source documents.")
    p.add_argument("--output", default=str(REPO_ROOT / "data/corpus.jsonl"))
    p.add_argument("--max-words", type=int, default=500)
    p.add_argument("--overlap", type=int, default=50)
    args = p.parse_args()

    inp = Path(args.input)
    if not inp.is_dir():
        print(f"Input directory not found: {inp}", file=sys.stderr)
        return 1

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    n_passages = 0
    with out_path.open("w", encoding="utf-8") as fh:
        for f in _iter_files(inp):
            text = f.read_text(encoding="utf-8", errors="ignore")
            chunks = _chunk(text, max_words=args.max_words, overlap=args.overlap)
            for i, chunk in enumerate(chunks):
                rec = {
                    "doc_id": f.stem,
                    "source": str(f.relative_to(inp)),
                    "section": f.stem,
                    "page": None,
                    "text": chunk,
                    "chunk": i,
                }
                fh.write(json.dumps(rec) + "\n")
                n_passages += 1

    print(f"Wrote {n_passages} passages to {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
