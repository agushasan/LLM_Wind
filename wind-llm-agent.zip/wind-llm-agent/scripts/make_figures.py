#!/usr/bin/env python
"""Reproduce Figures 2, 3, 4, 5 of the paper.

The figures are:

  fig_fault_timeseries.pdf  — Fig 2:  four SCADA channels over 30 days,
                                       with the fault marked at sample 1232
                                       and a 72-h pre-fault band shaded.
  fig_power_curve.pdf        — Fig 3:  active power vs. wind speed in two
                                       complementary colourings.
  fig_stationarity.pdf       — Fig 4:  rolling mean and std of generator
                                       speed and gearbox bearing temp.
  fig_correlation.pdf        — Fig 5:  channel correlation matrices for
                                       normal baseline, pre-fault, and the
                                       absolute difference.

If the SCADA CSV is absent, a synthetic case-study-shaped record is
generated so the figures still come out (with the same qualitative
features as those in the paper).
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from wind_llm_agent.data_loader import (            # noqa: E402
    FAULT_SAMPLE_INDEX, FAULT_TIMESTAMP,
    load_scada_csv, synthesise_demo_csv,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _prefault_window(df: pd.DataFrame, hours: int = 72) -> tuple[pd.Timestamp, pd.Timestamp]:
    end = df.index[FAULT_SAMPLE_INDEX]
    start = end - pd.Timedelta(hours=hours)
    return start, end


# ---------------------------------------------------------------------------
# Figure 2
# ---------------------------------------------------------------------------
def fig_fault_timeseries(df: pd.DataFrame, outdir: Path) -> Path:
    pre_start, pre_end = _prefault_window(df)
    fault_ts = df.index[FAULT_SAMPLE_INDEX]

    channels = [
        ("wind_speed",           "Wind speed [m/s]"),
        ("active_power",         "Active power [kW]"),
        ("gearbox_bearing_temp", "Gearbox bearing temp [°C]"),
        ("generator_temp_1",     "Generator temp 1 [°C]"),
    ]
    fig, axes = plt.subplots(len(channels), 1, figsize=(8, 8), sharex=True)
    for ax, (col, ylab) in zip(axes, channels):
        if col not in df:
            ax.text(0.5, 0.5, f"channel {col!r} missing", transform=ax.transAxes,
                    ha="center", va="center")
            continue
        ax.plot(df.index, df[col], lw=0.6, color="C0")
        ax.axvspan(pre_start, pre_end, color="orange", alpha=0.2,
                   label="72-h pre-fault window")
        ax.axvline(fault_ts, color="red", ls="--", lw=1.0,
                   label="documented fault (sample 1232)")
        ax.set_ylabel(ylab)
        ax.grid(alpha=0.3)
    axes[0].legend(loc="upper right", fontsize=8)
    axes[-1].set_xlabel("Date")
    fig.suptitle("Figure 2 — SCADA signals over the 30-day record")
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    out = outdir / "fig_fault_timeseries.pdf"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    return out


# ---------------------------------------------------------------------------
# Figure 3
# ---------------------------------------------------------------------------
def fig_power_curve(df: pd.DataFrame, outdir: Path) -> Path:
    pre_start, pre_end = _prefault_window(df)
    fault_ts = df.index[FAULT_SAMPLE_INDEX]

    sub = df.dropna(subset=["wind_speed", "active_power"]).copy()
    sub["regime"] = "normal"
    sub.loc[(sub.index >= pre_start) & (sub.index < pre_end), "regime"] = "pre-fault"
    sub.loc[sub.index >= fault_ts, "regime"] = "post-fault"

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))

    # Panel (a) — coloured by gearbox temp
    sc1 = axes[0].scatter(
        sub["wind_speed"], sub["active_power"],
        c=sub.get("gearbox_bearing_temp", np.zeros(len(sub))),
        s=4, cmap="viridis",
    )
    axes[0].set_xlabel("Wind speed [m/s]")
    axes[0].set_ylabel("Active power [kW]")
    axes[0].set_title("(a) coloured by gearbox bearing temp [°C]")
    axes[0].grid(alpha=0.3)
    fig.colorbar(sc1, ax=axes[0])

    # Panel (b) — coloured by operating regime
    palette = {"normal": "C0", "pre-fault": "C1", "post-fault": "C3"}
    for regime, group in sub.groupby("regime"):
        axes[1].scatter(group["wind_speed"], group["active_power"],
                        s=6, c=palette[regime], label=regime, alpha=0.7)
    axes[1].set_xlabel("Wind speed [m/s]")
    axes[1].set_ylabel("Active power [kW]")
    axes[1].set_title("(b) coloured by operating regime")
    axes[1].legend(loc="upper left", fontsize=8)
    axes[1].grid(alpha=0.3)

    fig.suptitle("Figure 3 — Wind-power curve of the case-study turbine")
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    out = outdir / "fig_power_curve.pdf"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    return out


# ---------------------------------------------------------------------------
# Figure 4
# ---------------------------------------------------------------------------
def fig_stationarity(df: pd.DataFrame, outdir: Path) -> Path:
    pre_start, pre_end = _prefault_window(df)
    fault_ts = df.index[FAULT_SAMPLE_INDEX]

    win = 72  # 12 h at 10-min cadence

    fig, axes = plt.subplots(2, 1, figsize=(9, 6), sharex=True)
    # (a) generator speed
    s = df.get("generator_speed")
    if s is not None:
        rm = s.rolling(win, min_periods=1).mean()
        rs = s.rolling(win, min_periods=1).std()
        axes[0].plot(s.index, rm, color="C0", label="rolling mean")
        axes[0].plot(s.index, rs, color="C1", label="rolling std")
        axes[0].set_ylabel("Generator speed [rpm]")
        axes[0].set_title("(a) Generator speed")
        axes[0].legend(loc="upper right", fontsize=8)
        axes[0].axvspan(pre_start, pre_end, color="orange", alpha=0.2)
        axes[0].axvline(fault_ts, color="red", ls="--", lw=0.8)
        axes[0].grid(alpha=0.3)
    # (b) gearbox bearing temp
    s = df.get("gearbox_bearing_temp")
    if s is not None:
        rm = s.rolling(win, min_periods=1).mean()
        rs = s.rolling(win, min_periods=1).std()
        axes[1].plot(s.index, rm, color="C3", label="rolling mean")
        axes[1].plot(s.index, rs, color="C4", label="rolling std")
        axes[1].set_ylabel("Gearbox bearing temp [°C]")
        axes[1].set_title("(b) Gearbox bearing temperature")
        axes[1].legend(loc="upper right", fontsize=8)
        axes[1].axvspan(pre_start, pre_end, color="orange", alpha=0.2)
        axes[1].axvline(fault_ts, color="red", ls="--", lw=0.8)
        axes[1].grid(alpha=0.3)
    axes[-1].set_xlabel("Date")
    fig.suptitle("Figure 4 — Stationarity diagnostic (tool T2)")
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    out = outdir / "fig_stationarity.pdf"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    return out


# ---------------------------------------------------------------------------
# Figure 5
# ---------------------------------------------------------------------------
def fig_correlation(df: pd.DataFrame, outdir: Path) -> Path:
    pre_start, pre_end = _prefault_window(df)

    baseline = df.loc["2012-11-01":"2012-11-07"]
    prefault = df.loc[pre_start:pre_end]

    cols = [c for c in [
        "wind_speed", "rotor_speed", "generator_speed", "active_power",
        "gearbox_bearing_temp", "generator_temp_1", "generator_temp_2",
    ] if c in df.columns]

    C_base = baseline[cols].corr().to_numpy()
    C_pre  = prefault[cols].corr().to_numpy()
    C_diff = np.abs(C_base - C_pre)

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
    titles = ["(a) Normal baseline\n(Nov 1–7)",
              "(b) 72-h pre-fault window",
              "(c) |Δ| between baseline and pre-fault"]
    mats = [C_base, C_pre, C_diff]
    cmaps = ["coolwarm", "coolwarm", "magma"]
    vmins = [-1, -1, 0]
    vmaxs = [ 1,  1, 0.5]
    for ax, t, M, cmap, vmn, vmx in zip(axes, titles, mats, cmaps, vmins, vmaxs):
        im = ax.imshow(M, cmap=cmap, vmin=vmn, vmax=vmx)
        ax.set_xticks(range(len(cols)))
        ax.set_yticks(range(len(cols)))
        ax.set_xticklabels(cols, rotation=45, ha="right", fontsize=7)
        ax.set_yticklabels(cols, fontsize=7)
        ax.set_title(t, fontsize=10)
        fig.colorbar(im, ax=ax, fraction=0.046)
    fig.suptitle("Figure 5 — Cross-channel correlation structure (tool T3)")
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    out = outdir / "fig_correlation.pdf"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    return out


# ---------------------------------------------------------------------------
def main() -> int:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--data", default=str(REPO_ROOT / "data/scada.csv"))
    p.add_argument("--outdir", default=str(REPO_ROOT / "figs"))
    args = p.parse_args()

    scada_path = Path(args.data)
    if not scada_path.exists():
        print(f"[make_figures] {scada_path} not found; synthesising demo data.",
              file=sys.stderr)
        scada_path.parent.mkdir(parents=True, exist_ok=True)
        synthesise_demo_csv(scada_path)

    df = load_scada_csv(scada_path)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    out_files = []
    out_files.append(fig_fault_timeseries(df, outdir))
    out_files.append(fig_power_curve(df, outdir))
    out_files.append(fig_stationarity(df, outdir))
    out_files.append(fig_correlation(df, outdir))

    print("Wrote:")
    for f in out_files:
        print(f"  {f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
