#!/usr/bin/env python
"""Run the wind-LLM-agent on a single operator query from the CLI.

Example
-------
    python scripts/run_agent.py \\
        --query "Are any turbines showing pre-fault signatures in the next 72 h?" \\
        --as-of 2012-11-07T09:00

The script:
  1. Loads (or synthesises) the SCADA CSV into a SharedState.
  2. Optionally loads a RAG corpus into T4 and a scheduler context into T5.
  3. Runs the agent loop against a local Ollama daemon.
  4. Prints the answer + a structured tool-call trace.

If the SCADA file is absent at the default path, a synthetic
case-study-shaped dataset is generated so the demo always runs.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import pandas as pd
import yaml


# --- repo-local import path -------------------------------------------------
REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from wind_llm_agent.data_loader import (             # noqa: E402
    load_scada_csv, synthesise_demo_csv,
)
from wind_llm_agent.state import SharedState         # noqa: E402
from wind_llm_agent.agent.registry import build_default_registry  # noqa: E402
from wind_llm_agent.agent.runtime import run_agent   # noqa: E402


# ---------------------------------------------------------------------------
def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--query", "-q", required=True,
                   help="Operator query in natural language.")
    p.add_argument("--as-of", default=None,
                   help="Set the 'current time' (ISO-8601). Default: end of data.")
    p.add_argument("--config", default=str(REPO_ROOT / "configs/default.yaml"))
    p.add_argument("--scada",  default=None, help="Override SCADA CSV path.")
    p.add_argument("--corpus", default=None, help="RAG corpus JSONL path.")
    p.add_argument("--model",  default=None, help="Override the Ollama model tag.")
    p.add_argument("--turbine-id", default="T1")
    p.add_argument("--max-steps", type=int, default=None)
    p.add_argument("--trace-out", default=None,
                   help="If set, write the structured trace as JSON to this path.")
    p.add_argument("-v", "--verbose", action="store_true")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(asctime)s %(levelname)s %(message)s",
    )

    cfg = yaml.safe_load(Path(args.config).read_text())

    # --- SCADA ----
    scada_path = Path(args.scada or cfg["paths"]["scada_csv"])
    if not scada_path.is_absolute():
        scada_path = REPO_ROOT / scada_path
    if not scada_path.exists():
        print(f"[run_agent] SCADA file not found at {scada_path}; "
              "synthesising demo data.", file=sys.stderr)
        scada_path.parent.mkdir(parents=True, exist_ok=True)
        synthesise_demo_csv(scada_path)
    df = load_scada_csv(scada_path)
    state = SharedState(scada=df, turbine_id=args.turbine_id)

    # Slice "as of" if requested, so the agent cannot look into the future.
    if args.as_of is not None:
        cutoff = pd.Timestamp(args.as_of)
        state.scada = state.scada.loc[:cutoff]

    # --- registry ----
    corpus_path = args.corpus or cfg["paths"].get("rag_corpus_jsonl")
    if corpus_path is not None:
        corpus_path = Path(corpus_path)
        if not corpus_path.is_absolute():
            corpus_path = REPO_ROOT / corpus_path
        if not corpus_path.exists():
            print(f"[run_agent] No RAG corpus at {corpus_path}; "
                  "T4 will be unavailable.", file=sys.stderr)
            corpus_path = None
        else:
            corpus_path = str(corpus_path)

    registry = build_default_registry(state, corpus_path=corpus_path)

    # --- run ----
    model_tag = args.model or cfg["model"]["name"]
    max_steps = args.max_steps or cfg["agent"]["max_steps"]
    result = run_agent(
        query=args.query,
        registry=registry,
        model=model_tag,
        max_steps=max_steps,
        temperature=cfg["model"]["temperature"],
        top_p=cfg["model"]["top_p"],
        seed=cfg["model"].get("seed"),
        host=cfg["model"]["host"],
        think=cfg["model"].get("think", False),
    )

    # --- output ----
    print("=" * 70)
    print(f"Model:        {model_tag}")
    print(f"Turns used:   {result.turns_used} / {max_steps}")
    print(f"Terminated:   {'normally' if result.terminated_normally else '⊥ (budget hit)'}")
    print("=" * 70)
    print("TRACE")
    for rec in result.trace:
        print(f"  [turn {rec.turn}] {rec.name}({json.dumps(rec.arguments)[:80]})")
        head = json.dumps(rec.result, default=str)
        print(f"      → {head[:160]}{'...' if len(head) > 160 else ''}")
    print("=" * 70)
    print("ANSWER")
    print(result.answer)
    print("=" * 70)

    if args.trace_out:
        result.save(args.trace_out)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
