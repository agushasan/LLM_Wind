#!/usr/bin/env python
"""Reproduce Table 4 of the paper.

Compares the proposed tool-calling agent against three baselines on a
held-out evaluation set of operator queries:

    B1   fixed-threshold SCADA alarm
    B2   isolation-forest anomaly detector
    B3   zero-shot Qwen3-14B (no tools)
    P    proposed agent (this repo)

For the structured query classes (Q1: health-check; Q4: predictive
alert) we report accuracy against ground-truth labels. For the
open-ended classes (Q2: root-cause; Q3: maintenance recommendation),
we report a placeholder rating column — the paper's numbers came from a
small human-rating panel, which is out of scope for an automated CLI.
You can plug your own LLM-as-judge here by editing `_rate_open_ended`.

Usage
-----
    python scripts/run_benchmark.py --queryset configs/eval_queries.json \\
                                     --methods proposed,b1_threshold,b2_iforest,b3_zeroshot
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from wind_llm_agent.data_loader import (             # noqa: E402
    load_scada_csv, synthesise_demo_csv,
)
from wind_llm_agent.state import SharedState         # noqa: E402
from wind_llm_agent.agent.registry import build_default_registry  # noqa: E402
from wind_llm_agent.agent.runtime import run_agent   # noqa: E402
from wind_llm_agent.baselines import (               # noqa: E402
    run_threshold_alarm, run_isolation_forest,
)


# ---------------------------------------------------------------------------
@dataclass
class EvalQuery:
    qid: str
    qclass: str                  # "Q1" .. "Q4"
    text: str
    as_of: str
    ground_truth: Optional[bool] = None      # for Q1/Q4

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "EvalQuery":
        return cls(
            qid=d["qid"], qclass=d["qclass"], text=d["text"],
            as_of=d["as_of"], ground_truth=d.get("ground_truth"),
        )


# ---------------------------------------------------------------------------
# Method runners — each returns either a bool decision (Q1/Q4) or a
# free-text answer (Q2/Q3).
# ---------------------------------------------------------------------------
def _slice_state(state: SharedState, as_of: str) -> SharedState:
    """Return a new SharedState whose scada is truncated at `as_of`."""
    sub = state.scada.loc[:pd.Timestamp(as_of)]
    return SharedState(scada=sub, turbine_id=state.turbine_id)


def run_proposed(query: EvalQuery, state: SharedState,
                 model: str, corpus_path: Optional[str]) -> Dict[str, Any]:
    sub = _slice_state(state, query.as_of)
    reg = build_default_registry(sub, corpus_path=corpus_path)
    result = run_agent(query.text, reg, model=model, max_steps=8, seed=42)
    # Heuristic decision: did the agent identify a pre-fault signature?
    decision = None
    text = (result.answer or "").lower()
    if query.qclass in ("Q1", "Q4"):
        decision = any(k in text for k in ("pre-fault", "anomaly",
                                           "developing fault",
                                           "decoupled", "inspection"))
    return {
        "method": "proposed",
        "decision": decision,
        "answer": result.answer,
        "n_turns": result.turns_used,
    }


def run_b1(query: EvalQuery, state: SharedState) -> Dict[str, Any]:
    sub = _slice_state(state, query.as_of)
    out = run_threshold_alarm(sub)
    decision = out["n_alarms"] > 0 if query.qclass in ("Q1", "Q4") else None
    return {"method": "b1_threshold", "decision": decision,
            "answer": None, "details": out}


def run_b2(query: EvalQuery, state: SharedState) -> Dict[str, Any]:
    sub = _slice_state(state, query.as_of)
    # Train on the first week of November as per the paper's protocol.
    out = run_isolation_forest(
        sub,
        train_start_ts="2012-11-01", train_end_ts="2012-11-07",
        eval_start_ts="2012-11-07", eval_end_ts=query.as_of,
        threshold=0.6,
    )
    decision = (out["n_above_threshold"] > 0
                if query.qclass in ("Q1", "Q4") else None)
    return {"method": "b2_iforest", "decision": decision,
            "answer": None, "details": out}


def run_b3(query: EvalQuery, state: SharedState, model: str) -> Dict[str, Any]:
    """Zero-shot Qwen3: no tools at all, no SCADA context, no manuals."""
    try:
        import ollama
    except ImportError:                                # pragma: no cover
        return {"method": "b3_zeroshot", "decision": None,
                "answer": None, "error": "ollama not installed"}
    client = ollama.Client(host="http://localhost:11434")
    resp = client.chat(model=model, messages=[
        {"role": "system",
         "content": ("You are an O&M assistant for a 2 MW Siemens wind "
                     "turbine. Answer concisely.")},
        {"role": "user", "content": query.text},
    ])
    text = resp["message"]["content"]
    decision = None
    if query.qclass in ("Q1", "Q4"):
        decision = any(k in text.lower()
                       for k in ("yes", "pre-fault", "anomaly",
                                 "developing fault", "inspection"))
    return {"method": "b3_zeroshot", "decision": decision, "answer": text}


# ---------------------------------------------------------------------------
def _rate_open_ended(answer: Optional[str]) -> Optional[float]:
    """Placeholder rater for Q2/Q3 — replace with your judge of choice."""
    if not answer:
        return None
    # Very simple heuristic: length, tool mentions, citation phrases.
    score = 0.0
    text = answer.lower()
    if 200 < len(text) < 3000: score += 1.5
    if "manual" in text or "section" in text or "§" in text: score += 1.0
    if "tool" in text or any(t in text for t in ("t1", "t2", "t3", "t4", "t5")):
        score += 1.0
    if "confidence" in text: score += 0.5
    return min(score, 5.0)


# ---------------------------------------------------------------------------
def main() -> int:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--data", default=str(REPO_ROOT / "data/scada.csv"))
    p.add_argument("--queryset",
                   default=str(REPO_ROOT / "configs/eval_queries.json"))
    p.add_argument("--methods", default="proposed,b1_threshold,b2_iforest,b3_zeroshot",
                   help="Comma-separated method names.")
    p.add_argument("--model", default="qwen3:14b")
    p.add_argument("--corpus", default=None)
    p.add_argument("--out", default=str(REPO_ROOT / "logs/benchmark.json"))
    args = p.parse_args()

    # Data
    scada_path = Path(args.data)
    if not scada_path.exists():
        synthesise_demo_csv(scada_path)
    df = load_scada_csv(scada_path)
    state = SharedState(scada=df, turbine_id="T1")

    # Queries
    qpath = Path(args.queryset)
    if not qpath.exists():
        # Minimal default set so the script always runs end-to-end.
        qpath.parent.mkdir(parents=True, exist_ok=True)
        qpath.write_text(json.dumps([
            {"qid": "q1a", "qclass": "Q1", "as_of": "2012-11-10T00:00",
             "text": "Is turbine T1 healthy right now?",
             "ground_truth": False},
            {"qid": "q4a", "qclass": "Q4", "as_of": "2012-11-07T09:00",
             "text": "Are any turbines showing pre-fault signatures in the next 72 h?",
             "ground_truth": True},
        ], indent=2))
    queries = [EvalQuery.from_dict(d) for d in json.loads(qpath.read_text())]

    methods = {m.strip() for m in args.methods.split(",")}
    rows: List[Dict[str, Any]] = []
    for q in queries:
        if "proposed" in methods:
            rows.append({"qid": q.qid, "qclass": q.qclass,
                         **run_proposed(q, state, args.model, args.corpus),
                         "ground_truth": q.ground_truth})
        if "b1_threshold" in methods:
            rows.append({"qid": q.qid, "qclass": q.qclass,
                         **run_b1(q, state), "ground_truth": q.ground_truth})
        if "b2_iforest" in methods:
            rows.append({"qid": q.qid, "qclass": q.qclass,
                         **run_b2(q, state), "ground_truth": q.ground_truth})
        if "b3_zeroshot" in methods:
            rows.append({"qid": q.qid, "qclass": q.qclass,
                         **run_b3(q, state, args.model),
                         "ground_truth": q.ground_truth})

    # Summary table: per-method accuracy on Q1/Q4 and rating on Q2/Q3.
    summary: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        m = r["method"]; qc = r["qclass"]
        bucket = summary.setdefault(m, {"Q1": [], "Q2": [], "Q3": [], "Q4": []})
        if qc in ("Q1", "Q4") and r["ground_truth"] is not None and r["decision"] is not None:
            bucket[qc].append(int(r["decision"] == r["ground_truth"]))
        elif qc in ("Q2", "Q3"):
            rate = _rate_open_ended(r.get("answer"))
            if rate is not None:
                bucket[qc].append(rate)

    print("\nMethod                Q1[acc%]  Q2[/5]  Q3[/5]  Q4[acc%]")
    print("-" * 56)
    for m, b in summary.items():
        def fmt(v, pct=False):
            if not v: return "  --   "
            avg = sum(v) / len(v)
            return f"{avg*100:6.1f}" if pct else f"{avg:6.2f}"
        print(f"{m:20s}  {fmt(b['Q1'], pct=True)}  {fmt(b['Q2'])}  "
              f"{fmt(b['Q3'])}  {fmt(b['Q4'], pct=True)}")

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps({
        "rows": rows, "summary": summary,
    }, indent=2, default=str))
    print(f"\nWrote detailed results to {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
