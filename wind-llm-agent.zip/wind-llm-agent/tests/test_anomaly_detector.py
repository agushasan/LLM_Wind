"""Unit tests for tool T2 (stationarity-based anomaly detector)."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from wind_llm_agent.data_loader import synthesise_demo_csv, load_scada_csv
from wind_llm_agent.state import SharedState
from wind_llm_agent.tools.anomaly_detector import anomaly_detector


@pytest.fixture(scope="module")
def state(tmp_path_factory) -> SharedState:
    p = tmp_path_factory.mktemp("data") / "scada.csv"
    synthesise_demo_csv(p, n_samples=4320)
    return SharedState(scada=load_scada_csv(p), turbine_id="T1")


def test_anomaly_detector_runs(state):
    out = anomaly_detector(
        state,
        channel_a="generator_speed",
        channel_b="gearbox_bearing_temp",
        start_ts="2012-11-01T00:00",
        end_ts="2012-11-10T00:00",
        window=72,
        threshold=3.0,
        test="zscore",
    )
    assert out["status"] == "ok"
    assert out["n_scores"] > 0


def test_anomaly_detector_finds_prefault(state):
    """The synthetic dataset puts a drift in [sample 800, 1232).

    T2 should detect at least one crossing inside that window.
    """
    out = anomaly_detector(
        state,
        channel_a="generator_speed",
        channel_b="gearbox_bearing_temp",
        start_ts="2012-11-01T00:00",
        end_ts="2012-11-09T13:00",
        window=72,
        threshold=2.0,        # slightly looser than default to be robust
        test="zscore",
    )
    assert out["n_crossings"] >= 1
    assert out["first_crossing_ts"] is not None


def test_anomaly_detector_insufficient_data(state):
    out = anomaly_detector(
        state,
        channel_a="generator_speed",
        channel_b="gearbox_bearing_temp",
        start_ts="2012-11-01T00:00",
        end_ts="2012-11-01T01:00",
        window=72,
    )
    assert out["status"] == "insufficient_data"


def test_anomaly_detector_unknown_channel(state):
    out = anomaly_detector(
        state,
        channel_a="nope",
        channel_b="gearbox_bearing_temp",
        start_ts="2012-11-01T00:00",
        end_ts="2012-11-02T00:00",
    )
    assert out["status"] == "unknown_channel"
