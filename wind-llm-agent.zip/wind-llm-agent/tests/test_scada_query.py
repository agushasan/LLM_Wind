"""Unit tests for tool T1 (SCADA query).

The contract under test is the structure of the return value: every
field documented in `schemas.py` must be present and well-typed, so the
LLM can rely on it.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from wind_llm_agent.data_loader import synthesise_demo_csv, load_scada_csv
from wind_llm_agent.state import SharedState
from wind_llm_agent.tools.scada_query import scada_query


@pytest.fixture(scope="module")
def state(tmp_path_factory) -> SharedState:
    p = tmp_path_factory.mktemp("data") / "scada.csv"
    synthesise_demo_csv(p, n_samples=4320)
    return SharedState(scada=load_scada_csv(p), turbine_id="T1")


def test_scada_query_returns_expected_keys(state):
    out = scada_query(
        state, channels=["active_power", "gearbox_bearing_temp"],
        start_ts="2012-11-01T00:00", end_ts="2012-11-02T00:00",
    )
    assert out["status"] == "ok"
    assert out["turbine_id"] == "T1"
    assert out["n_samples"] > 0
    assert set(out["channels"]) == {"active_power", "gearbox_bearing_temp"}
    for c, stats in out["channels"].items():
        assert stats["status"] != "no_data"
        for k in ("mean", "std", "min", "max", "argmax_ts", "argmin_ts", "n"):
            assert k in stats


def test_scada_query_offline_intervals(state):
    out = scada_query(
        state, channels=["active_power"],
        start_ts="2012-11-09T00:00", end_ts="2012-11-30T23:50",
        include_offline_intervals=True,
    )
    assert "offline_intervals" in out
    # Post-fault, we expect some non-zero offline runs.
    assert isinstance(out["offline_intervals"], list)


def test_scada_query_empty_window(state):
    out = scada_query(
        state, channels=["active_power"],
        start_ts="2099-01-01T00:00", end_ts="2099-01-02T00:00",
    )
    assert out["status"] == "empty_window"


def test_scada_query_unknown_channel(state):
    out = scada_query(
        state, channels=["not_a_channel"],
        start_ts="2012-11-01T00:00", end_ts="2012-11-02T00:00",
    )
    assert out["channels"]["not_a_channel"]["status"] == "unknown_channel"


def test_determinism(state):
    """Calling T1 twice with the same args returns equal numerics."""
    a = scada_query(state, channels=["active_power"],
                    start_ts="2012-11-01T00:00", end_ts="2012-11-02T00:00")
    b = scada_query(state, channels=["active_power"],
                    start_ts="2012-11-01T00:00", end_ts="2012-11-02T00:00")
    assert a["channels"]["active_power"]["mean"] == \
           b["channels"]["active_power"]["mean"]
