"""Unit tests for tool T3 (thermal / physics consistency check)."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from wind_llm_agent.data_loader import synthesise_demo_csv, load_scada_csv
from wind_llm_agent.state import SharedState
from wind_llm_agent.tools.physics_check import physics_check


@pytest.fixture(scope="module")
def state(tmp_path_factory) -> SharedState:
    p = tmp_path_factory.mktemp("data") / "scada.csv"
    synthesise_demo_csv(p, n_samples=4320)
    return SharedState(scada=load_scada_csv(p), turbine_id="T1")


def test_physics_check_returns_structure(state):
    out = physics_check(
        state,
        start_ts="2012-11-01T00:00",
        end_ts="2012-11-07T00:00",
    )
    assert out["status"] == "ok"
    assert "violations" in out
    assert isinstance(out["violations"], list)


def test_physics_check_detects_prefault_decoupling(state):
    """In the 72 h pre-fault window the gearbox–generator temperature
    correlation drops; T3 should flag at least one R3 violation."""
    out = physics_check(
        state,
        start_ts="2012-11-06T13:00",
        end_ts="2012-11-09T13:00",
        baseline_start_ts="2012-11-01T00:00",
        baseline_end_ts="2012-11-07T00:00",
        rho_min=0.90,
    )
    r3_violations = [v for v in out["violations"]
                     if v["rule"] == "R3_temperature_correlation"]
    assert len(r3_violations) >= 1
    # Each R3 violation should carry rho_observed; baseline gives delta.
    for v in r3_violations:
        assert "rho_observed" in v
        if out["baseline_used"]:
            assert "rho_baseline" in v
            assert "delta_rho" in v


def test_physics_check_empty(state):
    out = physics_check(
        state,
        start_ts="2099-01-01T00:00",
        end_ts="2099-01-02T00:00",
    )
    assert out["status"] == "empty_window"
