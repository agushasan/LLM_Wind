"""Tests for the agent runtime without requiring a live Ollama daemon.

We monkey-patch the ollama client with a stub that emits a fixed
sequence of tool-call messages, then a final assistant message. This
verifies the per-turn dispatch logic (equations 7–8) and the abstention
behaviour (equation 9) without any network calls.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from wind_llm_agent.data_loader import synthesise_demo_csv, load_scada_csv
from wind_llm_agent.state import SharedState
from wind_llm_agent.agent.registry import build_default_registry
from wind_llm_agent.agent import runtime as rt
from wind_llm_agent.agent.runtime import run_agent, BOTTOM


# ---------------------------------------------------------------------------
# A minimal stub for the ollama.Client
# ---------------------------------------------------------------------------
class _StubClient:
    """Returns a pre-programmed sequence of assistant messages."""

    def __init__(self, scripted: List[Dict[str, Any]]):
        self.scripted = list(scripted)
        self.calls: List[Dict[str, Any]] = []

    def chat(self, **kwargs):
        self.calls.append(kwargs)
        if not self.scripted:
            return {"message": {"content": "(unscripted)", "tool_calls": None}}
        msg = self.scripted.pop(0)
        return {"message": msg}


# ---------------------------------------------------------------------------
@pytest.fixture(scope="module")
def state(tmp_path_factory) -> SharedState:
    p = tmp_path_factory.mktemp("data") / "scada.csv"
    synthesise_demo_csv(p, n_samples=4320)
    return SharedState(scada=load_scada_csv(p), turbine_id="T1")


def _patch_client(monkeypatch, scripted):
    stub = _StubClient(scripted)
    class _Mod:
        @staticmethod
        def Client(host=""):  # noqa: N802 (mimic ollama API)
            return stub
    monkeypatch.setattr(rt, "ollama", _Mod)
    return stub


# ---------------------------------------------------------------------------
def test_runtime_dispatches_tool_and_terminates(state, monkeypatch):
    """One tool call then a final answer → AgentResult.terminated_normally."""
    scripted = [
        # Turn 1: ask for SCADA stats.
        {"role": "assistant", "content": "",
         "tool_calls": [{"function": {
             "name": "scada_query",
             "arguments": {
                 "channels": ["active_power"],
                 "start_ts": "2012-11-01T00:00",
                 "end_ts":   "2012-11-02T00:00",
             }
         }}]},
        # Turn 2: final answer.
        {"role": "assistant",
         "content": "Active power averaged X kW. Confidence: medium.",
         "tool_calls": None},
    ]
    _patch_client(monkeypatch, scripted)
    reg = build_default_registry(state, corpus_path=None)
    result = run_agent("Is T1 healthy?", reg, model="qwen3:14b",
                       max_steps=8, seed=42)
    assert result.terminated_normally
    assert result.turns_used == 2
    assert len(result.trace) == 1
    assert result.trace[0].name == "scada_query"


def test_runtime_returns_bottom_on_budget(state, monkeypatch):
    """If the model keeps calling tools and never terminates, ⊥ is returned."""
    # Eight consecutive tool calls — never a final answer.
    scripted = [
        {"role": "assistant", "content": "",
         "tool_calls": [{"function": {
             "name": "scada_query",
             "arguments": {
                 "channels": ["active_power"],
                 "start_ts": "2012-11-01T00:00",
                 "end_ts":   "2012-11-02T00:00",
             }
         }}]}
        for _ in range(8)
    ]
    _patch_client(monkeypatch, scripted)
    reg = build_default_registry(state, corpus_path=None)
    result = run_agent("loop please", reg, max_steps=8)
    assert result.terminated_normally is False
    assert result.answer == BOTTOM


def test_runtime_handles_bad_args_gracefully(state, monkeypatch):
    """If the LLM passes bad args, the tool returns an error dict; the
    runtime keeps going rather than crashing."""
    scripted = [
        {"role": "assistant", "content": "",
         "tool_calls": [{"function": {
             "name": "scada_query",
             "arguments": {"channels": ["active_power"]},  # missing ts
         }}]},
        {"role": "assistant", "content": "I had a problem.", "tool_calls": None},
    ]
    _patch_client(monkeypatch, scripted)
    reg = build_default_registry(state, corpus_path=None)
    result = run_agent("Test bad args", reg)
    assert result.terminated_normally
    assert result.trace[0].result.get("status") == "type_error"


def test_runtime_string_args_are_json_parsed(state, monkeypatch):
    """Some Ollama versions return tool_call arguments as JSON strings."""
    scripted = [
        {"role": "assistant", "content": "",
         "tool_calls": [{"function": {
             "name": "scada_query",
             "arguments": json.dumps({
                 "channels": ["active_power"],
                 "start_ts": "2012-11-01T00:00",
                 "end_ts":   "2012-11-02T00:00",
             }),
         }}]},
        {"role": "assistant", "content": "ok", "tool_calls": None},
    ]
    _patch_client(monkeypatch, scripted)
    reg = build_default_registry(state, corpus_path=None)
    result = run_agent("test json-string args", reg)
    assert result.terminated_normally
    assert result.trace[0].result.get("status") == "ok"
