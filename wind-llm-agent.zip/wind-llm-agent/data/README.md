# Data

The case study in the paper uses a publicly documented SCADA record from a 2 MW Siemens wind turbine on the Baltic Sea coast in northern Poland.

## Expected layout

Drop the dataset as:

```
data/
└── scada.csv          # 4 320 rows × 12 channels at 10-min resolution
```

The CSV should have a timestamp column (named `timestamp`, `datetime`, `time`, or `date_time`) and the twelve channels listed below. The data loader auto-renames common aliases to the canonical names used in the codebase — see `src/wind_llm_agent/data_loader.py:CANONICAL` for the full alias table.

| Group | Canonical name | Unit |
|-------|----------------|------|
| Rotational | `wind_speed` | m/s |
|            | `rotor_speed` | rpm |
|            | `generator_speed` | rpm |
| Electrical | `active_power` | kW |
|            | `reactive_power` | kvar |
|            | `generator_voltage` | V |
|            | `generator_current` | A |
|            | `active_power_delivered` | kW |
|            | `reactive_power_delivered` | kvar |
| Thermal    | `gearbox_bearing_temp` | °C |
|            | `generator_temp_1` | °C |
|            | `generator_temp_2` | °C |

## Documented fault

The dataset contains a single timestamped gearbox-bearing failure at:

| Sample index | Timestamp |
|--------------|-----------|
| `1232` | `2012-11-09 13:00` |

The constants `FAULT_SAMPLE_INDEX` and `FAULT_TIMESTAMP` in `data_loader.py` expose these for use in evaluation scripts.

## Known data-quality issue

Sixteen wind-speed entries in some upstream exports are corrupted by an automatic spreadsheet locale conversion that re-encoded numeric values like `9.87` as the string `sep.87` (interpreting `9` as the ordinal of September). The loader auto-corrects this when `fix_locale_corruption=True` (the default). See §4.2 of the paper.

## Don't have the real dataset?

The repository includes a `synthesise_demo_csv()` helper in `data_loader.py` that generates a structurally identical synthetic dataset with the same 30-day window, the same channel set, the same documented fault at sample 1232, and qualitatively similar pre-fault thermal drift and correlation decoupling. All scripts and tests fall back to this synthetic dataset transparently if `data/scada.csv` is absent, so the code runs end-to-end without the real CSV.

## RAG corpus

The retrieval tool T4 reads a JSONL corpus at `data/corpus.jsonl`. To build one from a directory of plain-text or markdown manual excerpts:

```bash
python scripts/build_rag_index.py --input data/manuals/ --output data/corpus.jsonl
```

If `data/corpus.jsonl` is absent, T4 returns `{"status": "tool_unavailable"}` and the agent reasons without it. This is the expected behaviour for users who want to evaluate the architecture on their own SCADA data before integrating their own documentation corpus.

## Citation / attribution

If you use the publicly documented SCADA record, please cite the source per its accompanying licence and any companion paper. The framework in this repository does not redistribute the dataset.
