# Manual §4.3.2 — Bearing Race Wear

Progressive temperature decoupling between the gearbox and the generator stages is an early indicator of bearing race wear. Under healthy operation, the Pearson correlation between the gearbox bearing temperature and either generator stator temperature exceeds 0.90 in any 12-hour window for which active power exceeds 500 kW. A drop of 0.15 or more, sustained over a 48-hour window, indicates that one bearing has begun to dissipate heat through friction independently of the load it is transmitting. The recommended response is a borescope inspection of the affected stage within 72 hours. If the inspection confirms surface micro-pitting, the bearing should be scheduled for replacement at the next planned vessel window.

# Manual §4.3.3 — Thermal Time Constants

The expected thermal time constant of the gearbox bearing assembly is approximately 90 minutes under step changes in load. After a sustained step from 25% to 75% rated power, the bearing temperature should reach 95% of its new steady-state value within three time constants (4.5 hours). Slow drift over a 24-hour period at constant load is inconsistent with the design and indicates either degraded cooling (filter blockage, pump failure) or progressive mechanical damage.

# Manual §6.1 — Vessel Access Constraints

Heavy-lift vessel operations require sustained significant wave height below 2.0 m and 10-minute mean wind speed below 12 m/s at the turbine location for the duration of the lift. Crew transfer vessel (CTV) operations have less stringent thresholds (wave height below 1.5 m, wind speed below 16 m/s) but cannot perform component replacement. For routine borescope inspection, CTV access is sufficient.
