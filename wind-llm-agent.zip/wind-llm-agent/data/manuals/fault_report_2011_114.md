# Fault Report 2011-114 — Sister-Turbine Bearing Race Failure

**Asset:** T-NWS-04 (2 MW Siemens, Baltic Sea coast)
**Date of failure:** 14 August 2011, 22:30 UTC
**Lead time of signature:** 5 days (first SCADA-detectable anomaly on 9 August 2011)
**Failed component:** Main gearbox bearing, high-speed stage

## Signature

The turbine exhibited a progressive decoupling of gearbox bearing temperature from generator stator temperature over the five days preceding failure. The Pearson correlation in 12-hour rolling windows dropped from 0.96 at the start of August to 0.71 immediately before the trip. The peak gearbox bearing temperature reached 78.4 °C on 13 August, approximately 8 °C above the seasonal norm for the load conditions on that day.

Generator-temperature-1 showed a corresponding excursion to 92.1 °C, well above its 50 °C normal-operation baseline at the prevailing wind speeds. The rolling standard deviation of generator speed narrowed from 132 to 105 rpm in the 72 hours preceding the trip, consistent with the controller locking the machine into a sustained high-load regime.

## Decision and outcome

The pre-fault signature was flagged manually by the day-shift operator on 12 August but was attributed to an external thermal source (warmer-than-usual ambient on a calm day) and no action was taken. The bearing failed catastrophically two days later, requiring a heavy-lift vessel mobilisation and a 17-day out-of-service event. The total cost was estimated at €184,000 including lost production.

## Lesson learned

The combined evidence of (i) gearbox–generator temperature decoupling and (ii) abnormally elevated generator stator temperature at a given load is sufficient grounds for an immediate borescope inspection, even when ambient conditions appear to offer a plausible alternative explanation. The cost of an unnecessary inspection is approximately €4,000; the cost of a missed early warning is two orders of magnitude higher.
