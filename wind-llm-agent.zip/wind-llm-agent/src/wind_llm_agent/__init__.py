"""Wind-LLM-Agent: a trustworthy LLM agent for wind-turbine O&M.

Reference implementation of

    Hasan, A., Widyotriatmo, A., Nguyen, D. T.
    "A Trustworthy Large Language Model Agent for Wind Turbine
    Operations and Maintenance."

This package exposes the five domain tools T1..T5 and the tool-calling
runtime that orchestrates them through an open-weight LLM (Qwen3 served
locally via Ollama).
"""

__version__ = "0.1.0"

from .state import SharedState
from .data_loader import load_scada_csv

__all__ = ["SharedState", "load_scada_csv", "__version__"]
