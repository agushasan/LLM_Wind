"""Baseline B2 — Isolation-forest anomaly detector.

A classical unsupervised detector. We train an `IsolationForest` on the
rotational and thermal channels of the first week of November (treated
as the normal-operation training window per the paper's protocol), then
score the rest of the record. The output is an anomaly score in
[-1, 1] and a per-sample binary flag.

Performs substantially better than B1 (Table 4: 79.2% vs 71.4% on Q1)
but produces only an anomaly score — no natural-language explanation,
no maintenance recommendation, no scheduling integration.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from ..state import SharedState


DEFAULT_FEATURES: List[str] = [
    "rotor_speed", "generator_speed",
    "gearbox_bearing_temp", "generator_temp_1", "generator_temp_2",
    "active_power",
]


@dataclass
class IsolationForestDetector:
    features: List[str]
    contamination: float = 0.05
    random_state: int = 42
    model: Any = None        # set in .fit()

    def fit(self, df: pd.DataFrame) -> "IsolationForestDetector":
        from sklearn.ensemble import IsolationForest

        X = df[self.features].dropna().to_numpy()
        self.model = IsolationForest(
            contamination=self.contamination,
            random_state=self.random_state,
            n_estimators=200,
        ).fit(X)
        return self

    def score(self, df: pd.DataFrame) -> pd.Series:
        if self.model is None:
            raise RuntimeError("Call .fit() before .score().")
        sub = df[self.features].dropna()
        s = -self.model.score_samples(sub.to_numpy())  # higher = more anomalous
        return pd.Series(s, index=sub.index, name="iforest_score")


def run_isolation_forest(
    state: SharedState,
    *,
    train_start_ts: Optional[str] = None,
    train_end_ts: Optional[str] = None,
    eval_start_ts: Optional[str] = None,
    eval_end_ts: Optional[str] = None,
    features: Sequence[str] = DEFAULT_FEATURES,
    contamination: float = 0.05,
    threshold: float = 0.6,
) -> Dict[str, Any]:
    """Train on `[train_start_ts, train_end_ts]`, score the eval window."""
    train_df = state.scada
    if train_start_ts is not None and train_end_ts is not None:
        train_df = state.window(
            pd.Timestamp(train_start_ts), pd.Timestamp(train_end_ts))
    eval_df = state.scada
    if eval_start_ts is not None and eval_end_ts is not None:
        eval_df = state.window(
            pd.Timestamp(eval_start_ts), pd.Timestamp(eval_end_ts))

    det = IsolationForestDetector(
        features=list(features), contamination=contamination
    ).fit(train_df)
    scores = det.score(eval_df)
    above = scores[scores > threshold]
    first = above.index.min().isoformat() if len(above) else None
    return {
        "status": "ok",
        "method": "B2_isolation_forest",
        "n_train_samples": int(len(train_df)),
        "n_eval_samples": int(len(eval_df)),
        "threshold": float(threshold),
        "n_above_threshold": int(len(above)),
        "max_score": float(scores.max()) if len(scores) else None,
        "first_above_ts": first,
    }
