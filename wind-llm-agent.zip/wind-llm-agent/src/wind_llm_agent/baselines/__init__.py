"""Baselines compared against the proposed agent in Table 4 of the paper.

* B1 — Fixed-threshold SCADA alarm
* B2 — Classical isolation-forest anomaly detector
* B3 — Zero-shot Qwen3-14B (no tools) — implemented inline in
  `scripts/run_benchmark.py` because it shares the Ollama client.
"""

from .threshold_alarm import ThresholdAlarm, run_threshold_alarm
from .isolation_forest import IsolationForestDetector, run_isolation_forest

__all__ = [
    "ThresholdAlarm",
    "run_threshold_alarm",
    "IsolationForestDetector",
    "run_isolation_forest",
]
