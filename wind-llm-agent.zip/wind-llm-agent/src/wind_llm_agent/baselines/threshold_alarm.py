"""Baseline B1 — Fixed-threshold SCADA alarm.

Mirrors the existing alarm logic deployed on the case-study turbine.
Each channel has a fixed upper / lower limit; the alarm fires when a
channel crosses its limit, with a configurable dwell time (number of
consecutive samples above the limit) to suppress single-sample spikes.

This baseline is the lowest-cost option to deploy but has poor
sensitivity at low fault severity, missing several pre-fault signals
in the 72-hour window before failure on the case-study dataset.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import pandas as pd

from ..state import SharedState


# Reference thresholds tuned to the 2 MW Siemens turbine on the
# case-study dataset. In production these come from the manufacturer's
# alarm-configuration sheet.
DEFAULT_LIMITS: Dict[str, Dict[str, float]] = {
    "gearbox_bearing_temp": {"upper": 75.0, "lower": -10.0},
    "generator_temp_1":     {"upper": 95.0, "lower":   0.0},
    "generator_temp_2":     {"upper": 95.0, "lower":   0.0},
    "generator_speed":      {"upper": 2000.0, "lower": -100.0},
    "active_power":         {"upper": 2100.0, "lower": -50.0},
}


@dataclass
class ThresholdAlarm:
    limits: Dict[str, Dict[str, float]] = field(
        default_factory=lambda: dict(DEFAULT_LIMITS))
    dwell_samples: int = 6                  # 1 h at 10-min cadence

    def alarms(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        for c, lim in self.limits.items():
            if c not in df:
                continue
            s = df[c]
            up = s > lim["upper"]
            dn = s < lim["lower"]
            # Run-length encode and emit alarms whose run length
            # reaches the dwell threshold.
            for label, mask in (("upper", up), ("lower", dn)):
                run = 0
                run_start: Optional[pd.Timestamp] = None
                for ts, v in mask.items():
                    if v:
                        run += 1
                        if run_start is None:
                            run_start = ts
                    else:
                        if run >= self.dwell_samples and run_start is not None:
                            out.append({
                                "channel": c,
                                "kind": label,
                                "threshold": float(lim[label]),
                                "start_ts": run_start.isoformat(),
                                "end_ts": ts.isoformat(),
                                "n_samples": int(run),
                            })
                        run = 0
                        run_start = None
                if run >= self.dwell_samples and run_start is not None:
                    out.append({
                        "channel": c,
                        "kind": label,
                        "threshold": float(lim[label]),
                        "start_ts": run_start.isoformat(),
                        "end_ts": s.index[-1].isoformat(),
                        "n_samples": int(run),
                    })
        return out


def run_threshold_alarm(
    state: SharedState,
    *,
    start_ts: Optional[str] = None,
    end_ts: Optional[str] = None,
    limits: Optional[Dict[str, Dict[str, float]]] = None,
    dwell_samples: int = 6,
) -> Dict[str, Any]:
    """Convenience wrapper matching the schema of the other tools."""
    df = state.scada
    if start_ts is not None and end_ts is not None:
        df = state.window(pd.Timestamp(start_ts), pd.Timestamp(end_ts))
    alarm = ThresholdAlarm(
        limits=limits or dict(DEFAULT_LIMITS),
        dwell_samples=dwell_samples,
    )
    out = alarm.alarms(df)
    return {
        "status": "ok",
        "method": "B1_fixed_threshold",
        "n_alarms": len(out),
        "alarms": out,
    }
