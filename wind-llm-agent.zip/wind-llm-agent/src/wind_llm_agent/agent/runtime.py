"""The tool-calling loop π_LLM.

This file implements equations (7)–(9) of the paper, in roughly the
same shape as Listing 1. The function returns an :class:`AgentResult`
that includes both the final natural-language answer and the structured
tool-call trace, so every numerical token in the answer can be audited
back to a specific tool return value (the grounding property,
Proposition 1).
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

try:
    import ollama
except ImportError:                                       # pragma: no cover
    ollama = None  # type: ignore[assignment]

from .registry import ToolRegistry
from ..tools.schemas import TOOL_SCHEMAS


log = logging.getLogger(__name__)


# A sentinel for the abstention token ⊥ in equation (9).
BOTTOM = "<<MAX_TOOL_CALL_BUDGET_REACHED>>"


# ---------------------------------------------------------------------------
# Result objects
# ---------------------------------------------------------------------------
@dataclass
class ToolCallRecord:
    turn: int
    name: str
    arguments: Dict[str, Any]
    result: Any


@dataclass
class AgentResult:
    """Bundle of final answer + full trace for downstream auditing."""
    answer: str
    trace: List[ToolCallRecord] = field(default_factory=list)
    turns_used: int = 0
    terminated_normally: bool = True
    messages: List[Dict[str, Any]] = field(default_factory=list)

    # --- handy serialisation -----------------------------------------
    def to_dict(self) -> Dict[str, Any]:
        return {
            "answer": self.answer,
            "turns_used": self.turns_used,
            "terminated_normally": self.terminated_normally,
            "trace": [
                {"turn": t.turn, "name": t.name,
                 "arguments": t.arguments, "result": t.result}
                for t in self.trace
            ],
        }

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), indent=2, default=str))


# ---------------------------------------------------------------------------
# System-prompt loader
# ---------------------------------------------------------------------------
_DEFAULT_PROMPT_PATH = (
    Path(__file__).resolve().parents[3] / "prompts" / "system_prompt.txt"
)


def _load_system_prompt(path: Optional[str | Path] = None) -> str:
    p = Path(path) if path is not None else _DEFAULT_PROMPT_PATH
    if p.exists():
        return p.read_text()
    return _MINIMAL_FALLBACK_PROMPT


_MINIMAL_FALLBACK_PROMPT = """You are an O&M decision-support agent for a wind farm.

You have access to five tools. NEVER produce numerical claims that are not
returned by a tool. NEVER reference manufacturer documentation that has not
been retrieved by the RAG tool. When tools disagree or no tool can answer,
report the uncertainty explicitly rather than guessing.

Tool descriptions are provided in the function-calling schema. Choose tools
deliberately; many queries are solved in a single call. End with a concise
natural-language answer that cites every tool you used.
"""


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------
def run_agent(
    query: str,
    registry: ToolRegistry,
    *,
    model: str = "qwen3:14b",
    max_steps: int = 8,
    temperature: float = 0.2,
    top_p: float = 0.9,
    seed: Optional[int] = None,
    host: str = "http://localhost:11434",
    system_prompt: Optional[str] = None,
    tools_schema: Sequence[Dict[str, Any]] = TOOL_SCHEMAS,
    think: bool = False,
) -> AgentResult:
    """Execute the agent on a single operator query.

    Parameters
    ----------
    query : str
        The natural-language operator question q_k.
    registry : ToolRegistry
        Holds the SharedState and any backends (RAG corpus, scheduler).
    model : str
        Ollama model tag (e.g. "qwen3:14b", "qwen3:8b").
    max_steps : int
        Turn budget J_max from equation (9).
    temperature, top_p : float
        Sampling parameters (the paper used 0.2 / 0.9).
    host : str
        Ollama HTTP endpoint.
    system_prompt : str, optional
        Override the default σ.
    think : bool
        Enable Qwen3's "thinking" mode for harder queries.

    Returns
    -------
    AgentResult
        Final answer + full structured trace.
    """
    if ollama is None:
        raise RuntimeError(
            "The `ollama` Python client is not installed. "
            "Run `pip install ollama` and ensure the daemon is running."
        )

    client = ollama.Client(host=host)

    messages: List[Dict[str, Any]] = [
        {"role": "system", "content": _load_system_prompt(system_prompt)},
        {"role": "user",   "content": query},
    ]
    trace: List[ToolCallRecord] = []
    options: Dict[str, Any] = {"temperature": temperature, "top_p": top_p}
    if seed is not None:
        options["seed"] = seed

    for step in range(1, max_steps + 1):
        resp = client.chat(
            model=model,
            messages=messages,
            tools=list(tools_schema),
            options=options,
            think=think,
        )
        msg: Dict[str, Any] = resp["message"]
        messages.append(msg)

        calls = msg.get("tool_calls") or []
        if not calls:
            return AgentResult(
                answer=msg.get("content", "") or "",
                trace=trace,
                turns_used=step,
                terminated_normally=True,
                messages=messages,
            )

        for c in calls:
            name = c["function"]["name"]
            args = c["function"]["arguments"]
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {}

            log.info("[turn %d] %s(%s)", step, name, args)
            try:
                result = registry.dispatch(name, args)
            except TypeError as e:                       # bad LLM args
                result = {"status": "type_error", "error": str(e)}
            except Exception as e:                       # pragma: no cover
                result = {"status": "tool_error", "error": str(e)}

            trace.append(ToolCallRecord(
                turn=step, name=name, arguments=args, result=result,
            ))
            messages.append({
                "role": "tool",
                "name": name,
                "content": json.dumps(result, default=str),
            })

    return AgentResult(
        answer=BOTTOM,
        trace=trace,
        turns_used=max_steps,
        terminated_normally=False,
        messages=messages,
    )
