"""Tool registry.

The LLM sees tool names and JSON-Schema arguments only. The
registry binds those names to Python callables and, importantly,
**hides the shared state from the LLM's argument list**: the agent
runtime always injects `state` (and any other backend dependencies)
explicitly when dispatching a tool call. The model cannot, for example,
pass a fabricated SCADA window into the SCADA-query tool.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional

from ..state import SharedState
from ..tools.scada_query import scada_query
from ..tools.anomaly_detector import anomaly_detector
from ..tools.physics_check import physics_check
from ..tools.rag_retriever import RagRetriever
from ..tools.maintenance_scheduler import (
    maintenance_scheduler, SchedulerContext, demo_context,
)


@dataclass
class ToolRegistry:
    """Bundle of (name → callable) bindings + injected backends.

    The runtime calls `dispatch(name, args)`; the registry takes care
    of injecting `state`, `retriever`, `scheduler_ctx`, etc.
    """

    state: SharedState
    retriever: Optional[RagRetriever] = None
    scheduler_ctx: Optional[SchedulerContext] = None
    extra: Dict[str, Callable[..., Any]] = field(default_factory=dict)

    # -- public dispatch ----------------------------------------------
    def dispatch(self, name: str, args: Dict[str, Any]) -> Any:
        """Run tool `name` with LLM-provided `args` against the state."""
        if name == "scada_query":
            return scada_query(self.state, **args)
        if name == "anomaly_detector":
            return anomaly_detector(self.state, **args)
        if name == "physics_check":
            return physics_check(self.state, **args)
        if name == "rag_retriever":
            if self.retriever is None:
                return {
                    "status": "tool_unavailable",
                    "reason": "no_corpus_loaded",
                }
            return self.retriever(**args)
        if name == "maintenance_scheduler":
            if self.scheduler_ctx is None:
                return {
                    "status": "tool_unavailable",
                    "reason": "no_scheduler_context",
                }
            return maintenance_scheduler(self.scheduler_ctx, **args)
        if name in self.extra:
            return self.extra[name](**args)
        return {"status": "unknown_tool", "name": name}

    # -- introspection -------------------------------------------------
    def names(self) -> list[str]:
        base = ["scada_query", "anomaly_detector", "physics_check",
                "rag_retriever", "maintenance_scheduler"]
        return base + list(self.extra)


def build_default_registry(
    state: SharedState,
    *,
    corpus_path: Optional[str] = None,
    scheduler_ctx: Optional[SchedulerContext] = None,
) -> ToolRegistry:
    """Convenience factory used by `scripts/run_agent.py`.

    If `corpus_path` is None, T4 is registered as unavailable, which
    causes the agent to gracefully skip retrieval-based reasoning. If
    `scheduler_ctx` is None, a synthetic demo context is used.
    """
    retriever: Optional[RagRetriever] = None
    if corpus_path is not None:
        retriever = RagRetriever.from_jsonl(corpus_path).build()
    if scheduler_ctx is None:
        scheduler_ctx = demo_context()
    return ToolRegistry(state=state, retriever=retriever,
                        scheduler_ctx=scheduler_ctx)
