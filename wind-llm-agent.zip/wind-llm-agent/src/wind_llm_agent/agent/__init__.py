"""Agent runtime: the tool-calling loop that orchestrates 𝒯 through Qwen3.

The runtime is a direct implementation of the per-turn dynamics in
equations (7)–(9) of the paper. It is intentionally tiny — under 250
lines — because all the work is done inside the tools and the LLM.
"""

from .runtime import run_agent, AgentResult, BOTTOM
from .registry import ToolRegistry, build_default_registry

__all__ = [
    "run_agent",
    "AgentResult",
    "BOTTOM",
    "ToolRegistry",
    "build_default_registry",
]
