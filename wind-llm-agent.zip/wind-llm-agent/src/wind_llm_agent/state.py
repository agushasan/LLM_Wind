"""Shared state Ξ_k = (𝒴_k, s_k, 𝓗_k).

In the paper, the diagnostic pipeline operates on a triple of objects:

* 𝒴_k — a sliding window of raw SCADA measurements (L × m matrix).
* s_k — a vector of derived health indicators (from the feature-level
  operator M_θ).
* 𝓗_k — a chronologically ordered event log.

All five tools are *pure functions* of this shared state and their own
tool-specific argument α. Centralising the state in a single object
makes that purity easy to enforce and tools easy to test in isolation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd


@dataclass
class SharedState:
    """Bundle of (𝒴_k, s_k, 𝓗_k) plus the channel-name mapping.

    Parameters
    ----------
    scada : pd.DataFrame
        Full SCADA stream indexed by timestamp; columns are channel
        names. Tools slice this on demand.
    indicators : np.ndarray, optional
        Pre-computed indicator vector s_k from the feature-level
        operator. If None, tools that need indicators will compute
        them on the fly from `scada`.
    event_log : list of (timestamp, event) tuples
        Chronologically ordered events (alarms, mode switches, operator
        annotations). Updated in-place when tools detect new events.
    turbine_id : str
        Identifier used by tools when more than one turbine is loaded.
    """

    scada: pd.DataFrame
    indicators: Optional[np.ndarray] = None
    event_log: List[Tuple[pd.Timestamp, str]] = field(default_factory=list)
    turbine_id: str = "T1"

    # ------------------------------------------------------------------
    # Convenience accessors
    # ------------------------------------------------------------------
    def window(self, start, end) -> pd.DataFrame:
        """Return the rows of `scada` in [start, end] (inclusive)."""
        return self.scada.loc[start:end]

    def channels(self) -> List[str]:
        return list(self.scada.columns)

    def append_event(self, timestamp, message: str) -> None:
        ts = pd.Timestamp(timestamp)
        self.event_log.append((ts, message))

    # ------------------------------------------------------------------
    # Pretty repr for logging / debugging
    # ------------------------------------------------------------------
    def __repr__(self) -> str:
        n = len(self.scada)
        first = self.scada.index[0] if n else "-"
        last = self.scada.index[-1] if n else "-"
        return (
            f"SharedState(turbine={self.turbine_id!r}, "
            f"samples={n}, channels={len(self.scada.columns)}, "
            f"period=[{first}, {last}], events={len(self.event_log)})"
        )
