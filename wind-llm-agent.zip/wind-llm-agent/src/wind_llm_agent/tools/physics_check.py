"""T3 — Thermal / Physics Consistency Check.

Implements the rule-based checks of §4.3 (paragraph T3) in the paper.
The three rules encoded here are:

    R1  Temperature–load monotonicity:
        for sustained high active power, gearbox bearing temperature
        should rise monotonically with a known time constant.

    R2  Current–power proportionality:
        at fixed voltage, generator current should scale approximately
        linearly with active power.

    R3  Cross-temperature correlation (equation 14):
        ρ(gearbox_bearing_temp, generator_temp_i) ≥ ρ_min   for i=1,2.

The tool returns a structured list of any rule violations, with the
quantitative gap. Tools T1 and T2 give early warning of *something*
changing; T3 says what that change physically means.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from ..state import SharedState


# ---------------------------------------------------------------------------
# Individual rule evaluators
# ---------------------------------------------------------------------------
def _rule_r1_temp_load_monotonicity(
    df: pd.DataFrame, power_threshold: float = 1500.0
) -> Optional[Dict[str, Any]]:
    """R1: gearbox temp should be non-decreasing in sustained high power."""
    if "gearbox_bearing_temp" not in df or "active_power" not in df:
        return None
    high = df[df["active_power"] > power_threshold]
    if len(high) < 12:               # need >= 2 h at rated
        return None
    temp = high["gearbox_bearing_temp"].rolling(6, min_periods=3).mean()
    diffs = temp.diff().dropna()
    # We tolerate up to 5 % of samples having a small negative drift.
    bad = diffs[diffs < -0.5]        # > 0.5 °C drop is suspicious
    if len(bad) / max(1, len(diffs)) > 0.05:
        return {
            "rule": "R1_temp_load_monotonicity",
            "status": "violated",
            "fraction_anomalous_drops": float(len(bad) / len(diffs)),
            "n_high_load_samples": int(len(high)),
            "worst_drop_C": float(bad.min()) if not bad.empty else None,
        }
    return None


def _rule_r2_current_power_linearity(
    df: pd.DataFrame, min_power: float = 100.0
) -> Optional[Dict[str, Any]]:
    """R2: I ∝ P at fixed V."""
    if "generator_current" not in df or "active_power" not in df:
        return None
    mask = df["active_power"] > min_power
    if mask.sum() < 50:
        return None
    p = df.loc[mask, "active_power"].to_numpy()
    i = df.loc[mask, "generator_current"].to_numpy()
    # Pearson correlation between P and I should be near 1.
    if p.std() < 1e-6 or i.std() < 1e-6:
        return None
    rho = float(np.corrcoef(p, i)[0, 1])
    if rho < 0.92:
        return {
            "rule": "R2_current_power_linearity",
            "status": "violated",
            "rho_observed": rho,
            "rho_threshold": 0.92,
            "n_samples": int(mask.sum()),
        }
    return None


def _rule_r3_temperature_correlation(
    df: pd.DataFrame, rho_min: float, baseline_df: Optional[pd.DataFrame],
) -> List[Dict[str, Any]]:
    """R3: ρ(T_gbx, T_gen_i) ≥ ρ_min.

    Returns one entry per violating pair. When a baseline window is
    given, we also report the *change* in correlation, which is the
    quantity the paper highlights (the 0.18–0.19 drop).
    """
    out: List[Dict[str, Any]] = []
    if "gearbox_bearing_temp" not in df:
        return out

    pairs = [("gearbox_bearing_temp", "generator_temp_1"),
             ("gearbox_bearing_temp", "generator_temp_2")]

    for a, b in pairs:
        if b not in df:
            continue
        sub = df[[a, b]].dropna()
        if len(sub) < 30 or sub[a].std() < 1e-6 or sub[b].std() < 1e-6:
            continue
        rho = float(np.corrcoef(sub[a], sub[b])[0, 1])

        baseline_rho = None
        delta = None
        if baseline_df is not None and a in baseline_df and b in baseline_df:
            bsub = baseline_df[[a, b]].dropna()
            if len(bsub) >= 30 and bsub[a].std() > 1e-6 and bsub[b].std() > 1e-6:
                baseline_rho = float(np.corrcoef(bsub[a], bsub[b])[0, 1])
                delta = baseline_rho - rho

        if rho < rho_min:
            entry: Dict[str, Any] = {
                "rule": "R3_temperature_correlation",
                "status": "violated",
                "channel_a": a,
                "channel_b": b,
                "rho_observed": rho,
                "rho_threshold": float(rho_min),
            }
            if baseline_rho is not None:
                entry["rho_baseline"] = baseline_rho
                entry["delta_rho"] = delta
            out.append(entry)
    return out


# ---------------------------------------------------------------------------
# Public tool
# ---------------------------------------------------------------------------
def physics_check(
    state: SharedState,
    *,
    start_ts: str,
    end_ts: str,
    baseline_start_ts: Optional[str] = None,
    baseline_end_ts: Optional[str] = None,
    rho_min: float = 0.85,
) -> Dict[str, Any]:
    """T3: evaluate the physics rules on the window [start_ts, end_ts].

    If `baseline_start_ts` / `baseline_end_ts` are supplied, R3 will
    additionally report the *change* in correlation against the
    baseline (the headline `Δρ ≈ 0.19` in the case study).
    """
    df = state.window(pd.Timestamp(start_ts), pd.Timestamp(end_ts))
    if df.empty:
        return {"status": "empty_window", "violations": []}

    baseline_df: Optional[pd.DataFrame] = None
    if baseline_start_ts is not None and baseline_end_ts is not None:
        baseline_df = state.window(
            pd.Timestamp(baseline_start_ts),
            pd.Timestamp(baseline_end_ts),
        )

    violations: List[Dict[str, Any]] = []

    if (v := _rule_r1_temp_load_monotonicity(df)) is not None:
        violations.append(v)
    if (v := _rule_r2_current_power_linearity(df)) is not None:
        violations.append(v)
    violations.extend(
        _rule_r3_temperature_correlation(df, rho_min, baseline_df)
    )

    # Record T3 events on the shared state.
    for v in violations:
        state.append_event(
            pd.Timestamp(start_ts),
            f"T3 violation: {v['rule']} (status={v['status']})",
        )

    return {
        "status": "ok",
        "n_samples": int(len(df)),
        "n_violations": len(violations),
        "violations": violations,
        "baseline_used": baseline_df is not None,
    }
