"""T4 — Retrieval-Augmented Generation Tool.

Vector-similarity search over a corpus of manufacturer manuals, prior
maintenance work-order narratives, and historical fault reports. The
corpus is chunked into ~500-token passages with 50-token overlap and
indexed in a FAISS in-memory database.

The retriever is exposed to the LLM as a single tool. The agent calls
it with a natural-language query and a top-k integer and receives a
list of passages with their source identifiers (document name, page,
section) so the final answer can cite the source verbatim.

Two backends are supported:

* ``faiss`` — production backend, requires `pip install faiss-cpu`
  and `sentence-transformers`.
* ``numpy`` — fallback that works without FAISS. Cosine similarity
  computed by brute force; fine up to ~10 k passages.

The default is to try faiss first and fall back transparently.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# Embedding model loader (lazy)
# ---------------------------------------------------------------------------
_EMBED_MODEL = None
_EMBED_MODEL_NAME: Optional[str] = None


def _get_embed_model(model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
    global _EMBED_MODEL, _EMBED_MODEL_NAME
    if _EMBED_MODEL is not None and _EMBED_MODEL_NAME == model_name:
        return _EMBED_MODEL
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as e:  # pragma: no cover
        raise RuntimeError(
            "T4 needs sentence-transformers: pip install sentence-transformers"
        ) from e
    _EMBED_MODEL = SentenceTransformer(model_name)
    _EMBED_MODEL_NAME = model_name
    return _EMBED_MODEL


# ---------------------------------------------------------------------------
# Corpus container
# ---------------------------------------------------------------------------
@dataclass
class Passage:
    """A single retrievable chunk of text."""
    text: str
    source: str               # e.g. "manual_v3.pdf"
    section: str = ""         # e.g. "§4.3.2 Bearing Race Wear"
    page: Optional[int] = None
    doc_id: str = ""


@dataclass
class RagCorpus:
    """In-memory corpus + embedding index."""
    passages: List[Passage] = field(default_factory=list)
    embeddings: Optional[np.ndarray] = None    # (N, D) row-normalised
    faiss_index: Any = None                    # set lazily

    # ----- construction -----
    @classmethod
    def from_jsonl(cls, path: str | Path) -> "RagCorpus":
        """Load a corpus from a JSONL file (one passage per line)."""
        passages: List[Passage] = []
        with Path(path).open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                d = json.loads(line)
                passages.append(Passage(
                    text=d["text"],
                    source=d.get("source", ""),
                    section=d.get("section", ""),
                    page=d.get("page"),
                    doc_id=d.get("doc_id", ""),
                ))
        return cls(passages=passages)

    # ----- indexing -----
    def embed(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
        """Compute and store row-normalised embeddings for every passage."""
        model = _get_embed_model(model_name)
        texts = [p.text for p in self.passages]
        vecs = np.asarray(
            model.encode(texts, show_progress_bar=False),
            dtype=np.float32,
        )
        # Row-normalise so dot product = cosine similarity.
        norms = np.linalg.norm(vecs, axis=1, keepdims=True)
        norms = np.where(norms > 0, norms, 1.0)
        self.embeddings = vecs / norms
        # Try to build a FAISS index for fast top-k.
        try:
            import faiss
            d = self.embeddings.shape[1]
            self.faiss_index = faiss.IndexFlatIP(d)
            self.faiss_index.add(self.embeddings)
        except ImportError:
            self.faiss_index = None
        return self

    # ----- retrieval -----
    def search(self, query: str, k: int = 3,
               model_name: str = "sentence-transformers/all-MiniLM-L6-v2"
               ) -> List[Tuple[float, Passage]]:
        if self.embeddings is None:
            raise RuntimeError("Corpus has not been embedded; call .embed() first.")
        model = _get_embed_model(model_name)
        q = np.asarray(model.encode([query]), dtype=np.float32)
        q /= np.linalg.norm(q, axis=1, keepdims=True).clip(min=1e-9)

        if self.faiss_index is not None:
            scores, idx = self.faiss_index.search(q, k)
            scores, idx = scores[0], idx[0]
        else:
            sims = (self.embeddings @ q.T).ravel()
            idx = np.argpartition(-sims, min(k, len(sims) - 1))[:k]
            idx = idx[np.argsort(-sims[idx])]
            scores = sims[idx]
        return [(float(scores[i]), self.passages[int(idx[i])])
                for i in range(len(idx))]


# ---------------------------------------------------------------------------
# Wrapper class for use as a tool implementation
# ---------------------------------------------------------------------------
class RagRetriever:
    """Stateful wrapper that holds a corpus and exposes a tool fn.

    Use:

        retriever = RagRetriever.from_jsonl("data/corpus.jsonl").build()
        tool_impls["rag_retriever"] = retriever  # callable

    The instance is callable with the same signature as the bare
    `rag_retriever` function below, but binds the corpus implicitly.
    """

    def __init__(self, corpus: RagCorpus):
        self.corpus = corpus

    @classmethod
    def from_jsonl(cls, path: str | Path) -> "RagRetriever":
        return cls(RagCorpus.from_jsonl(path))

    def build(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2"
              ) -> "RagRetriever":
        self.corpus.embed(model_name=model_name)
        return self

    def __call__(self, *, query: str, k: int = 3, **_) -> Dict[str, Any]:
        hits = self.corpus.search(query, k=k)
        return {
            "status": "ok",
            "query": query,
            "k": int(k),
            "results": [
                {
                    "rank": i + 1,
                    "score": float(score),
                    "source": p.source,
                    "section": p.section,
                    "page": p.page,
                    "doc_id": p.doc_id,
                    "text": p.text,
                }
                for i, (score, p) in enumerate(hits)
            ],
        }


# ---------------------------------------------------------------------------
# Convenience: bare function form for the simplest possible wiring
# ---------------------------------------------------------------------------
def rag_retriever(corpus: RagCorpus, *, query: str, k: int = 3) -> Dict[str, Any]:
    """Stateless variant — explicit corpus argument."""
    return RagRetriever(corpus)(query=query, k=k)
