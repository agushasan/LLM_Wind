"""T5 — Maintenance Scheduler.

Constrained search over future maintenance windows. Given a recommended
action and a forecast horizon, the tool returns the earliest feasible
window subject to:

    (i)   sig. wave height forecast < vessel threshold
    (ii)  wind-speed forecast < vessel threshold
    (iii) qualified crew available
    (iv)  required parts in inventory
    (v)   no conflicting maintenance already booked on neighbouring
          turbines

The implementation here is intentionally a *reference* — in production
it would wrap the operator's actual ERP / weather / crew systems. The
data structures (`WeatherForecast`, `CrewRoster`, `PartsInventory`,
`MaintenanceCalendar`) are designed to be replaced one-for-one with
adapters to those systems.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd


# ---------------------------------------------------------------------------
# Plug-in data sources (all replaceable)
# ---------------------------------------------------------------------------
@dataclass
class WeatherForecast:
    """Time-indexed forecast of wave height and wind speed."""
    series: pd.DataFrame                # cols: 'wave_m', 'wind_ms'

    def feasible(self, ts: pd.Timestamp,
                 wave_max: float, wind_max: float) -> bool:
        if ts not in self.series.index:
            # Nearest-neighbour fallback for forecasts on coarser grids.
            try:
                row = self.series.iloc[self.series.index.get_indexer([ts], method="nearest")[0]]
            except Exception:
                return False
        else:
            row = self.series.loc[ts]
        return bool(row["wave_m"] <= wave_max and row["wind_ms"] <= wind_max)


@dataclass
class CrewRoster:
    available_slots: List[Tuple[pd.Timestamp, pd.Timestamp]] = field(default_factory=list)

    def available(self, ts0: pd.Timestamp, ts1: pd.Timestamp) -> bool:
        return any(s0 <= ts0 and s1 >= ts1 for s0, s1 in self.available_slots)


@dataclass
class PartsInventory:
    parts: Dict[str, int] = field(default_factory=dict)   # part_id → qty

    def has(self, required: Dict[str, int]) -> bool:
        return all(self.parts.get(k, 0) >= v for k, v in required.items())


@dataclass
class MaintenanceCalendar:
    booked: List[Tuple[pd.Timestamp, pd.Timestamp, str]] = field(default_factory=list)

    def conflict(self, ts0: pd.Timestamp, ts1: pd.Timestamp) -> bool:
        return any(b0 < ts1 and b1 > ts0 for b0, b1, _ in self.booked)


# Default action → required parts map. Real operators will replace this
# with their bill-of-materials lookup.
ACTION_PARTS: Dict[str, Dict[str, int]] = {
    "borescope inspection":   {},                       # no parts
    "oil sample":             {},
    "bearing replacement":    {"main_bearing": 1},
    "yaw motor replacement":  {"yaw_motor": 1},
    "blade pitch service":    {"pitch_grease_kg": 4},
    "derate":                 {},
}


# ---------------------------------------------------------------------------
# Configuration container
# ---------------------------------------------------------------------------
@dataclass
class SchedulerContext:
    """Bundled dependencies — typically built once at agent startup."""
    weather: WeatherForecast
    crew:    CrewRoster
    parts:   PartsInventory
    calendar: MaintenanceCalendar
    slot_length_hours: int = 8


# ---------------------------------------------------------------------------
# Public tool
# ---------------------------------------------------------------------------
def maintenance_scheduler(
    ctx: SchedulerContext,
    *,
    action: str,
    horizon_hours: int = 168,
    vessel_wave_threshold_m: float = 2.0,
    vessel_wind_threshold_ms: float = 12.0,
    n_candidates: int = 3,
    start_from: Optional[pd.Timestamp] = None,
) -> Dict[str, Any]:
    """T5: return the earliest feasible windows for `action`.

    The search granularity matches the forecast index resolution
    (typically hourly).
    """
    start_from = pd.Timestamp(start_from) if start_from is not None \
        else ctx.weather.series.index.min()
    end_at = start_from + pd.Timedelta(hours=int(horizon_hours))

    required = ACTION_PARTS.get(action, {})
    if not ctx.parts.has(required):
        missing = {k: v for k, v in required.items()
                   if ctx.parts.parts.get(k, 0) < v}
        return {
            "status": "blocked",
            "reason": "parts_unavailable",
            "missing_parts": missing,
        }

    candidates: List[Dict[str, Any]] = []
    cursor = start_from
    slot = pd.Timedelta(hours=ctx.slot_length_hours)
    step = pd.Timedelta(hours=1)

    while cursor + slot <= end_at and len(candidates) < n_candidates:
        ts0 = cursor
        ts1 = cursor + slot
        if (ctx.weather.feasible(ts0, vessel_wave_threshold_m,
                                 vessel_wind_threshold_ms)
                and ctx.weather.feasible(ts1, vessel_wave_threshold_m,
                                         vessel_wind_threshold_ms)
                and ctx.crew.available(ts0, ts1)
                and not ctx.calendar.conflict(ts0, ts1)):
            candidates.append({
                "start": ts0.isoformat(),
                "end":   ts1.isoformat(),
                "duration_h": int(ctx.slot_length_hours),
                "weather_at_start": {
                    "wave_m": float(ctx.weather.series.iloc[
                        ctx.weather.series.index.get_indexer([ts0], method="nearest")[0]
                    ]["wave_m"]),
                    "wind_ms": float(ctx.weather.series.iloc[
                        ctx.weather.series.index.get_indexer([ts0], method="nearest")[0]
                    ]["wind_ms"]),
                },
            })
            cursor = ts1                  # do not overlap candidates
        else:
            cursor = cursor + step

    if not candidates:
        return {
            "status": "no_window_found",
            "horizon_hours": int(horizon_hours),
            "thresholds": {
                "wave_m": vessel_wave_threshold_m,
                "wind_ms": vessel_wind_threshold_ms,
            },
        }

    return {
        "status": "ok",
        "action": action,
        "n_candidates": len(candidates),
        "candidates": candidates,
        "thresholds": {
            "wave_m": vessel_wave_threshold_m,
            "wind_ms": vessel_wind_threshold_ms,
        },
    }


# ---------------------------------------------------------------------------
# Minimal demo context (used by tests and by scripts/run_agent.py
# when no real operator backend is configured).
# ---------------------------------------------------------------------------
def demo_context(start: str = "2012-11-07 12:00",
                 horizon_hours: int = 168) -> SchedulerContext:
    """Build a deterministic synthetic scheduler context."""
    import numpy as np
    rng = np.random.default_rng(7)
    idx = pd.date_range(start=start, periods=horizon_hours + 1, freq="h")
    wave = 1.2 + 0.8 * np.sin(np.linspace(0, 6, len(idx))) \
           + rng.normal(0, 0.2, len(idx))
    wind = 8.0 + 4.0 * np.cos(np.linspace(0, 6, len(idx))) \
           + rng.normal(0, 1.0, len(idx))
    forecast = pd.DataFrame({"wave_m": wave, "wind_ms": wind}, index=idx)
    return SchedulerContext(
        weather=WeatherForecast(series=forecast),
        crew=CrewRoster(available_slots=[
            (pd.Timestamp(start), pd.Timestamp(start)
             + pd.Timedelta(hours=horizon_hours))
        ]),
        parts=PartsInventory(parts={"main_bearing": 0,
                                    "yaw_motor": 0,
                                    "pitch_grease_kg": 20}),
        calendar=MaintenanceCalendar(booked=[]),
    )
