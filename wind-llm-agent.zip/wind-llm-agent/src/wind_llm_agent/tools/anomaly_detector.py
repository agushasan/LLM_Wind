"""T2 — Stationarity-based Anomaly Detector.

Implements the detector specified in equation (12) of the paper. Given
two channels (c1, c2), we form the centred-and-scaled bivariate signal

    ỹ_k^{(c)} = (y_k^{(c)} - μ_ref^{(c)}) / σ_ref^{(c)}

and slide a window of length L over the joint signal. For each window
we compute a stationarity test statistic a_k, and emit an anomaly flag
whenever a_k > τ.

Three test statistics are supported:

* ``adf``    — augmented Dickey–Fuller (null: unit root → non-stationary)
* ``kpss``   — KPSS test (null: stationary)
* ``zscore`` — simple windowed z-score of the cross-covariance,
               implemented in pure NumPy. This is the default because
               it has no statsmodels dependency and runs in <1 ms per
               window on the full 30-day record.

The default channel pair is (generator_speed, gearbox_bearing_temp),
following the methodology validated for this dataset in prior work.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from ..state import SharedState


# ---------------------------------------------------------------------------
# Score functions
# ---------------------------------------------------------------------------
def _zscore_stat(window: np.ndarray, ref_mean: np.ndarray,
                 ref_std: np.ndarray) -> float:
    """Standardised cross-covariance magnitude of a window.

    Returns |z| where z is the mean of the elementwise z-scored window;
    large |z| means the window is far from the reference distribution.
    """
    if window.shape[0] < 2:
        return 0.0
    z = (window - ref_mean) / np.where(ref_std > 0, ref_std, 1.0)
    # Cross-covariance between the two channels in the window:
    cov = float(np.mean(z[:, 0] * z[:, 1]))
    # Plus a magnitude term so univariate drift is also caught.
    mag = float(np.mean(np.linalg.norm(z, axis=1)))
    return abs(cov) + 0.5 * mag


def _adf_stat(window: np.ndarray) -> float:
    """Augmented Dickey–Fuller test statistic on a univariate series.

    We use the L2-norm of the bivariate window as a summary signal so a
    single statistic captures coupled non-stationarity. The result is
    the negative of the ADF stat so larger means "more anomalous"
    (consistent with the threshold convention τ above).

    statsmodels is imported lazily to keep the default code path
    dependency-free.
    """
    try:
        from statsmodels.tsa.stattools import adfuller
    except ImportError as e:  # pragma: no cover - optional dep
        raise RuntimeError(
            "ADF test requires statsmodels: pip install statsmodels"
        ) from e
    signal = np.linalg.norm(window, axis=1)
    if signal.std() < 1e-9:
        return 0.0
    stat, *_ = adfuller(signal, regression="c", autolag="AIC")
    return float(-stat)


def _kpss_stat(window: np.ndarray) -> float:
    """KPSS test statistic on the L2-norm of the bivariate window."""
    try:
        from statsmodels.tsa.stattools import kpss
    except ImportError as e:  # pragma: no cover
        raise RuntimeError(
            "KPSS test requires statsmodels: pip install statsmodels"
        ) from e
    signal = np.linalg.norm(window, axis=1)
    if signal.std() < 1e-9:
        return 0.0
    stat, *_ = kpss(signal, regression="c", nlags="auto")
    return float(stat)


_TEST_FNS = {
    "zscore": _zscore_stat,
    "adf":    _adf_stat,
    "kpss":   _kpss_stat,
}


# ---------------------------------------------------------------------------
# Public tool
# ---------------------------------------------------------------------------
def anomaly_detector(
    state: SharedState,
    *,
    channel_a: str = "generator_speed",
    channel_b: str = "gearbox_bearing_temp",
    start_ts: str,
    end_ts: str,
    window: int = 72,
    threshold: float = 3.0,
    test: str = "zscore",
    reference_window: Optional[Tuple[str, str]] = None,
) -> Dict[str, Any]:
    """T2: sliding-window stationarity-based anomaly detector.

    The reference distribution is estimated from the *first 25 %* of the
    requested period unless `reference_window` is given. In a production
    deployment the reference is usually a fixed known-normal stretch
    set when the operator commissions the tool.
    """
    if channel_a not in state.scada.columns or channel_b not in state.scada.columns:
        return {
            "status": "unknown_channel",
            "channel_a": channel_a,
            "channel_b": channel_b,
        }

    df = state.window(pd.Timestamp(start_ts), pd.Timestamp(end_ts))
    df = df[[channel_a, channel_b]].dropna()
    if len(df) < window:
        return {
            "status": "insufficient_data",
            "samples_available": int(len(df)),
            "window_required": int(window),
        }

    # Reference distribution.
    if reference_window is not None:
        rs, re_ = reference_window
        ref = state.window(pd.Timestamp(rs), pd.Timestamp(re_))[[channel_a, channel_b]].dropna()
    else:
        ref = df.iloc[: max(window, len(df) // 4)]
    ref_mean = ref.to_numpy().mean(axis=0)
    ref_std = ref.to_numpy().std(axis=0)

    # Slide and score.
    arr = df.to_numpy()
    if test == "zscore":
        scores = np.empty(len(arr) - window + 1)
        for i in range(len(scores)):
            scores[i] = _zscore_stat(arr[i:i + window], ref_mean, ref_std)
    else:
        fn = _TEST_FNS[test]
        scores = np.empty(len(arr) - window + 1)
        z_arr = (arr - ref_mean) / np.where(ref_std > 0, ref_std, 1.0)
        for i in range(len(scores)):
            scores[i] = fn(z_arr[i:i + window])

    score_times = df.index[window - 1:]
    crossings_mask = scores > threshold
    first_crossing = (
        score_times[np.argmax(crossings_mask)].isoformat()
        if crossings_mask.any() else None
    )
    crossings: List[str] = [t.isoformat()
                            for t in score_times[crossings_mask]]

    # Record the event(s) on the shared state's event log.
    if first_crossing is not None:
        state.append_event(
            first_crossing,
            f"T2 first crossing on ({channel_a}, {channel_b}) "
            f"at score>{threshold:.2f}",
        )

    return {
        "status": "ok",
        "channel_a": channel_a,
        "channel_b": channel_b,
        "test": test,
        "threshold": float(threshold),
        "window": int(window),
        "n_scores": int(len(scores)),
        "max_score": float(scores.max()),
        "mean_score": float(scores.mean()),
        "first_crossing_ts": first_crossing,
        "n_crossings": int(crossings_mask.sum()),
        # We do not return the full score vector — too large for the
        # LLM context window. The agent can call again with a narrower
        # window if it needs detail.
        "crossings_sample":
            crossings[: min(10, len(crossings))],
    }
