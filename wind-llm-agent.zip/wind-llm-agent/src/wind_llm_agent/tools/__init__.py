"""Tool library 𝒯 = {T1, ..., T5} (§4.3 of the paper).

Every tool is a pure function of `SharedState` plus a tool-specific
argument α, returning a value v ∈ 𝒱_i. The JSON-Schema descriptions of
each tool's argument and return type live in `schemas.py`; the
implementations are in the per-tool modules.

The functions in this package are deterministic. Given the same
SharedState and the same argument they return the same output, modulo
floating-point round-off. This determinism is what gives the agent its
consistency property (Proposition 2 in the paper).
"""

from .scada_query import scada_query
from .anomaly_detector import anomaly_detector
from .physics_check import physics_check
from .rag_retriever import rag_retriever, RagRetriever
from .maintenance_scheduler import maintenance_scheduler
from .schemas import TOOL_SCHEMAS

__all__ = [
    "scada_query",
    "anomaly_detector",
    "physics_check",
    "rag_retriever",
    "RagRetriever",
    "maintenance_scheduler",
    "TOOL_SCHEMAS",
]
