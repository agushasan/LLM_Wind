"""JSON-Schema definitions for all five tools.

These schemas are what the LLM sees: when the agent runtime calls
`client.chat(..., tools=TOOL_SCHEMAS)`, Qwen3 receives this list as the
declaration of its action space. The contract here MUST stay in sync
with the function signatures in `scada_query.py`, `anomaly_detector.py`,
etc., because Ollama dispatches by function name + argument keys.

The schemas follow the OpenAI function-calling convention, which Ollama
exposes natively.
"""

TOOL_SCHEMAS = [
    # ------------------------------------------------------------------
    # T1 — SCADA Query
    # ------------------------------------------------------------------
    {
        "type": "function",
        "function": {
            "name": "scada_query",
            "description": (
                "Return descriptive statistics (mean, std, min, max, "
                "argmax) for one or more SCADA channels over a "
                "time window. Optionally returns a list of intervals "
                "where active power was zero (turbine offline)."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "channels": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description":
                            "Channel names, e.g. ['active_power', "
                            "'gearbox_bearing_temp']. See data_loader."
                            "CANONICAL for the full list.",
                    },
                    "start_ts": {
                        "type": "string",
                        "description": "ISO-8601 start timestamp.",
                    },
                    "end_ts": {
                        "type": "string",
                        "description": "ISO-8601 end timestamp.",
                    },
                    "include_offline_intervals": {
                        "type": "boolean",
                        "default": False,
                    },
                },
                "required": ["channels", "start_ts", "end_ts"],
            },
        },
    },

    # ------------------------------------------------------------------
    # T2 — Anomaly Detector (stationarity-based)
    # ------------------------------------------------------------------
    {
        "type": "function",
        "function": {
            "name": "anomaly_detector",
            "description": (
                "Run a stationarity-based anomaly detector on a pair "
                "of SCADA channels. Returns the time series of "
                "anomaly scores and the indices of any threshold "
                "crossings."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "channel_a": {"type": "string"},
                    "channel_b": {"type": "string"},
                    "start_ts":  {"type": "string"},
                    "end_ts":    {"type": "string"},
                    "window":    {
                        "type": "integer",
                        "default": 72,
                        "description":
                            "Rolling window length in samples "
                            "(10-min resolution → 72 = 12 h).",
                    },
                    "threshold": {
                        "type": "number",
                        "default": 3.0,
                        "description":
                            "Z-score threshold on the test statistic.",
                    },
                    "test": {
                        "type": "string",
                        "enum": ["adf", "kpss", "zscore"],
                        "default": "zscore",
                    },
                },
                "required": ["channel_a", "channel_b",
                             "start_ts", "end_ts"],
            },
        },
    },

    # ------------------------------------------------------------------
    # T3 — Thermal / Physics Check
    # ------------------------------------------------------------------
    {
        "type": "function",
        "function": {
            "name": "physics_check",
            "description": (
                "Evaluate a small set of physical-consistency rules on "
                "the SCADA window (temperature correlations, "
                "load–temperature monotonicity, "
                "current–power proportionality). Returns the list of "
                "rule violations."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "start_ts":      {"type": "string"},
                    "end_ts":        {"type": "string"},
                    "baseline_start_ts": {
                        "type": "string",
                        "description":
                            "Start of the normal-operation baseline "
                            "used to calibrate correlation thresholds.",
                    },
                    "baseline_end_ts":   {"type": "string"},
                    "rho_min": {
                        "type": "number",
                        "default": 0.85,
                        "description":
                            "Minimum acceptable Pearson correlation "
                            "between gearbox and generator temperatures.",
                    },
                },
                "required": ["start_ts", "end_ts"],
            },
        },
    },

    # ------------------------------------------------------------------
    # T4 — RAG Retriever
    # ------------------------------------------------------------------
    {
        "type": "function",
        "function": {
            "name": "rag_retriever",
            "description": (
                "Vector-similarity search over the corpus of manuals, "
                "prior fault reports, and historical work orders. "
                "Returns the top-k passages with their source ids."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "k":     {"type": "integer", "default": 3},
                },
                "required": ["query"],
            },
        },
    },

    # ------------------------------------------------------------------
    # T5 — Maintenance Scheduler
    # ------------------------------------------------------------------
    {
        "type": "function",
        "function": {
            "name": "maintenance_scheduler",
            "description": (
                "Find the earliest feasible maintenance window for a "
                "recommended action, subject to weather, crew, parts, "
                "and conflict constraints. Returns a list of candidate "
                "windows in chronological order."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "description":
                            "e.g. 'borescope inspection', "
                            "'bearing replacement', 'derate'.",
                    },
                    "horizon_hours": {
                        "type": "integer",
                        "default": 168,
                    },
                    "vessel_wave_threshold_m": {
                        "type": "number",
                        "default": 2.0,
                    },
                    "vessel_wind_threshold_ms": {
                        "type": "number",
                        "default": 12.0,
                    },
                },
                "required": ["action"],
            },
        },
    },
]
