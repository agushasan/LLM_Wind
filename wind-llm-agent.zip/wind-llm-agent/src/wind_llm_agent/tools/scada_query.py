"""T1 — SCADA Query.

Implements the rolling-statistic accumulators of equations (10) and (11)
in the paper. Given a channel set 𝓒 and a time window [k₁, k₂], this
tool returns:

    μ_c   = mean over the window
    σ_c   = standard deviation over the window
    min_c, max_c, argmax_c
    optionally: list of intervals where active_power == 0
                (turbine offline)

The implementation is intentionally minimal — fewer than a hundred
lines — because the role of T1 in the architecture is to centralise
SCADA access, not to do clever analytics. Cleverness lives in T2 and
T3, which call T1 internally for their own slicing.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from ..state import SharedState


def _offline_intervals(
    power: pd.Series, threshold_kw: float = 1.0
) -> List[Dict[str, str]]:
    """Return contiguous intervals where active_power < threshold_kw."""
    offline = power < threshold_kw
    if not offline.any():
        return []
    # Run-length encoding over the boolean mask.
    changes = offline.ne(offline.shift())
    groups = changes.cumsum()
    out: List[Dict[str, str]] = []
    for _, idx in offline.groupby(groups).groups.items():
        if offline.loc[idx[0]]:
            out.append({
                "start": idx[0].isoformat(),
                "end":   idx[-1].isoformat(),
                "duration_min": int(
                    (idx[-1] - idx[0]).total_seconds() // 60
                ),
            })
    return out


def scada_query(
    state: SharedState,
    *,
    channels: List[str],
    start_ts: str,
    end_ts: str,
    include_offline_intervals: bool = False,
) -> Dict[str, Any]:
    """T1: descriptive statistics over [start_ts, end_ts].

    Parameters
    ----------
    state : SharedState
        The shared state Ξ_k. Injected by the agent runtime, not by the
        LLM.
    channels : list of str
        Canonical channel names. Unknown channels are ignored (the
        LLM is told which channels exist via the system prompt).
    start_ts, end_ts : str (ISO-8601)
        Half-open interval in pandas convention.
    include_offline_intervals : bool
        If True, also return a list of intervals during which
        active_power was zero.

    Returns
    -------
    dict
        Structured result that the agent can read directly.
    """
    df = state.window(pd.Timestamp(start_ts), pd.Timestamp(end_ts))
    if df.empty:
        return {
            "status": "empty_window",
            "channels": {},
            "n_samples": 0,
            "start_ts": start_ts,
            "end_ts": end_ts,
        }

    result: Dict[str, Any] = {
        "status": "ok",
        "turbine_id": state.turbine_id,
        "start_ts": start_ts,
        "end_ts": end_ts,
        "n_samples": int(len(df)),
        "channels": {},
    }
    for c in channels:
        if c not in df.columns:
            result["channels"][c] = {"status": "unknown_channel"}
            continue
        s: pd.Series = df[c].dropna()
        if s.empty:
            result["channels"][c] = {"status": "no_data"}
            continue
        result["channels"][c] = {
            "mean":   float(s.mean()),
            "std":    float(s.std(ddof=1)) if len(s) > 1 else 0.0,
            "min":    float(s.min()),
            "max":    float(s.max()),
            "argmax_ts": s.idxmax().isoformat(),
            "argmin_ts": s.idxmin().isoformat(),
            "n":       int(len(s)),
        }

    if include_offline_intervals and "active_power" in df.columns:
        result["offline_intervals"] = _offline_intervals(df["active_power"])

    return result
