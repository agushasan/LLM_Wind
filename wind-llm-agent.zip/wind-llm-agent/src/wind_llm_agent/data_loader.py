"""SCADA data loader for the case-study dataset.

The 30-day record from the 2 MW Siemens turbine on the Baltic Sea coast
contains 4 320 samples at 10-minute resolution across twelve channels.
We standardise the column names so the rest of the codebase does not
depend on the upstream header style.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd


# Canonical channel names used throughout the codebase. The CSV may
# arrive with any of the listed aliases; we map them all here.
CANONICAL = {
    # rotational
    "wind_speed":            ["WindSpeed", "wind_speed", "v_wind", "Vwind", "wind"],
    "rotor_speed":           ["RotorSpeed", "rotor_speed", "n_rotor"],
    "generator_speed":       ["GenSpd", "GeneratorSpeed", "n_gen", "generator_speed"],
    # electrical
    "active_power":          ["P", "ActivePower", "active_power", "P_active"],
    "reactive_power":        ["Q", "ReactivePower", "reactive_power"],
    "generator_voltage":     ["GenVoltage", "U_gen", "generator_voltage"],
    "generator_current":     ["GenCurrent", "I_gen", "generator_current"],
    "active_power_delivered":  ["Pdel", "active_power_delivered"],
    "reactive_power_delivered": ["Qdel", "reactive_power_delivered"],
    # thermal
    "gearbox_bearing_temp":  ["GbxBrgTemp", "GearboxBearingTemp",
                              "gearbox_bearing_temp", "T_gbx"],
    "generator_temp_1":      ["GenTemp1", "generator_temp_1", "T_gen1"],
    "generator_temp_2":      ["GenTemp2", "generator_temp_2", "T_gen2"],
}

# The documented gearbox-bearing failure: sample 1232, 2012-11-09 13:00.
FAULT_SAMPLE_INDEX = 1232
FAULT_TIMESTAMP = pd.Timestamp("2012-11-09 13:00")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------
def _rename_to_canonical(df: pd.DataFrame) -> pd.DataFrame:
    """Rename whichever alias is present in df to its canonical name."""
    rename = {}
    for canon, aliases in CANONICAL.items():
        for a in aliases:
            if a in df.columns:
                rename[a] = canon
                break
    return df.rename(columns=rename)


def _fix_spreadsheet_locale_corruption(series: pd.Series) -> pd.Series:
    """Reverse the "9.87 → sep.87" locale corruption documented in §4.2.

    When the upstream CSV was exported through a localised spreadsheet,
    sixteen wind-speed cells were silently re-encoded as month-day
    strings. We invert that mapping here.
    """
    months = {
        "jan": 1, "feb": 2, "mar": 3, "apr": 4, "mai": 5, "may": 5,
        "jun": 6, "jul": 7, "aug": 8, "sep": 9, "okt": 10, "oct": 10,
        "nov": 11, "des": 12, "dec": 12,
    }
    def coerce(x):
        if isinstance(x, (int, float, np.integer, np.floating)):
            return float(x)
        if not isinstance(x, str):
            return np.nan
        s = x.strip().lower()
        for tok, mnum in months.items():
            if s.startswith(tok + "."):
                # "sep.87" → 9.87
                tail = s.split(".", 1)[1]
                try:
                    return float(f"{mnum}.{tail}")
                except ValueError:
                    return np.nan
        try:
            return float(s)
        except ValueError:
            return np.nan
    return series.map(coerce).astype(float)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def load_scada_csv(
    path: str | Path,
    *,
    fix_locale_corruption: bool = True,
    timestamp_col: Optional[str] = None,
) -> pd.DataFrame:
    """Load and clean the case-study SCADA CSV.

    Parameters
    ----------
    path : str or Path
        Path to the CSV file.
    fix_locale_corruption : bool, default True
        Apply the wind-speed locale-corruption fix (§4.2 in the paper).
    timestamp_col : str, optional
        Name of the timestamp column. If None, common defaults are
        tried. If no timestamp column is found, a 10-minute-resolution
        index starting 2012-11-01 00:00 is synthesised.

    Returns
    -------
    pd.DataFrame
        Cleaned SCADA frame indexed by timestamp with canonical column
        names.
    """
    path = Path(path)
    df = pd.read_csv(path)

    # Find or synthesise the timestamp column.
    ts_candidates = ["timestamp", "datetime", "date_time", "time"]
    if timestamp_col is None:
        for c in ts_candidates:
            if c in df.columns:
                timestamp_col = c
                break

    if timestamp_col is not None and timestamp_col in df.columns:
        df[timestamp_col] = pd.to_datetime(df[timestamp_col])
        df = df.set_index(timestamp_col)
    else:
        df.index = pd.date_range(
            start="2012-11-01 00:00", periods=len(df), freq="10min"
        )

    df = _rename_to_canonical(df)

    if fix_locale_corruption and "wind_speed" in df.columns:
        df["wind_speed"] = _fix_spreadsheet_locale_corruption(df["wind_speed"])

    # Cast numeric columns to float, leaving any non-numeric extras alone.
    for c in df.columns:
        if c in CANONICAL:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    return df


def synthesise_demo_csv(path: str | Path, n_samples: int = 4320) -> Path:
    """Generate a synthetic SCADA CSV with the case-study structure.

    Used by `tests/` and by users who do not have the real dataset yet.
    The synthetic stream has a gentle thermal drift and a correlation
    breakdown in the 72 h before sample 1232, so the same tools and the
    same agent prompts produce qualitatively similar traces.
    """
    rng = np.random.default_rng(42)
    t = pd.date_range("2012-11-01 00:00", periods=n_samples, freq="10min")
    wind = np.clip(8 + 3 * np.sin(np.linspace(0, 30, n_samples))
                   + rng.normal(0, 1.5, n_samples), 0, 25)
    rotor = np.clip(wind * 1.4, 0, 16) + rng.normal(0, 0.3, n_samples)
    gen   = rotor * 95 + rng.normal(0, 10, n_samples)
    power = np.clip((wind / 12) ** 3 * 2000, 0, 2000) + rng.normal(0, 30, n_samples)

    # Thermal coupling: T = a*P + b + slow drift; we add an extra
    # bump on the gearbox in the 72 h before sample 1232.
    base_gbx  = 0.025 * power + 25 + rng.normal(0, 1.5, n_samples)
    base_gen1 = 0.038 * power + 30 + rng.normal(0, 1.8, n_samples)
    base_gen2 = 0.040 * power + 30 + rng.normal(0, 1.8, n_samples)
    drift = np.zeros(n_samples)
    drift[FAULT_SAMPLE_INDEX - 432:FAULT_SAMPLE_INDEX] = np.linspace(0, 15, 432)
    gbx = base_gbx + drift
    # After the fault, repeated trips to zero.
    trip_mask = np.zeros(n_samples, dtype=bool)
    for k in range(FAULT_SAMPLE_INDEX, n_samples, 60):
        trip_mask[k:k + rng.integers(5, 30)] = True
    rotor[trip_mask] = 0.0
    gen[trip_mask] = 0.0
    power[trip_mask] = 0.0

    df = pd.DataFrame({
        "timestamp": t,
        "wind_speed": wind,
        "rotor_speed": rotor,
        "generator_speed": gen,
        "active_power": power,
        "reactive_power": rng.normal(0, 50, n_samples),
        "generator_voltage": 690 + rng.normal(0, 5, n_samples),
        "generator_current": np.clip(power / 1.0, 0, 2400)
                             + rng.normal(0, 20, n_samples),
        "active_power_delivered":   power * 0.98,
        "reactive_power_delivered": rng.normal(0, 50, n_samples),
        "gearbox_bearing_temp": gbx,
        "generator_temp_1":     base_gen1,
        "generator_temp_2":     base_gen2,
    })
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    return path
